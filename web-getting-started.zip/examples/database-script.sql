USE [master]
GO
/****** Object:  Database [webapplication7]    Script Date: 1/15/2022 4:54:15 PM ******/
CREATE DATABASE [webapplication7]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'webapplication7', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS01\MSSQL\DATA\webapplication7.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'webapplication7_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS01\MSSQL\DATA\webapplication7_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
USE [webapplication7]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 1/15/2022 4:54:44 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER AUTHORIZATION ON [dbo].[__EFMigrationsHistory] TO  SCHEMA OWNER 
GO
/****** Object:  Table [dbo].[Categories]    Script Date: 1/15/2022 4:54:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categories](
	[UID] [uniqueidentifier] NOT NULL,
	[Description] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[RowVersion] [varbinary](max) NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER AUTHORIZATION ON [dbo].[Categories] TO  SCHEMA OWNER 
GO
/****** Object:  Table [dbo].[Colors]    Script Date: 1/15/2022 4:54:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Colors](
	[UID] [uniqueidentifier] NOT NULL,
	[Description] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[RowVersion] [varbinary](max) NULL,
 CONSTRAINT [PK_Colors] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER AUTHORIZATION ON [dbo].[Colors] TO  SCHEMA OWNER 
GO
/****** Object:  Table [dbo].[Employees]    Script Date: 1/15/2022 4:54:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employees](
	[Id] [nvarchar](450) NOT NULL,
	[Designation] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Salary] [decimal](18, 2) NULL,
 CONSTRAINT [PK_Employees] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER AUTHORIZATION ON [dbo].[Employees] TO  SCHEMA OWNER 
GO
/****** Object:  Table [dbo].[Units]    Script Date: 1/15/2022 4:54:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Units](
	[UID] [uniqueidentifier] NOT NULL,
	[Description] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[RowVersion] [varbinary](max) NULL,
 CONSTRAINT [PK_Units] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER AUTHORIZATION ON [dbo].[Units] TO  SCHEMA OWNER 
GO
INSERT [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion]) VALUES (N'20180713073110_Migration1', N'2.0.1-rtm-125')
GO
INSERT [dbo].[Categories] ([UID], [Description], [Name], [RowVersion]) VALUES (N'262f5749-97b4-4f06-8431-25ca02b023ee', N'description0', N'category0', NULL)
GO
INSERT [dbo].[Categories] ([UID], [Description], [Name], [RowVersion]) VALUES (N'629dc93a-bfd6-4c98-b6e9-513506868d62', N'description1', N'category1', NULL)
GO
INSERT [dbo].[Categories] ([UID], [Description], [Name], [RowVersion]) VALUES (N'10f24cc0-4a68-43ea-aa98-bcd1ba16da2a', N'description2', N'category2', NULL)
GO
INSERT [dbo].[Colors] ([UID], [Description], [Name], [RowVersion]) VALUES (N'a6a2b1ae-c32a-469f-a10a-100e33353eb2', N'description1', N'color1', NULL)
GO
INSERT [dbo].[Colors] ([UID], [Description], [Name], [RowVersion]) VALUES (N'48648eae-77eb-4647-a258-35d377b7a571', N'description0', N'color0', NULL)
GO
INSERT [dbo].[Colors] ([UID], [Description], [Name], [RowVersion]) VALUES (N'5c7f146c-be75-4787-983e-5437592bc2ba', N'description2', N'color2', NULL)
GO
INSERT [dbo].[Employees] ([Id], [Designation], [Name], [Salary]) VALUES (N'2', N'Office Boy', N'Employee 2', CAST(10000.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Employees] ([Id], [Designation], [Name], [Salary]) VALUES (N'3', N'Manager', N'Employee 3', CAST(15000.00 AS Decimal(18, 2)))
GO
INSERT [dbo].[Units] ([UID], [Description], [Name], [RowVersion]) VALUES (N'34472423-ded9-453a-90e9-593cdfd074a7', N'description0', N'unit0', NULL)
GO
INSERT [dbo].[Units] ([UID], [Description], [Name], [RowVersion]) VALUES (N'27d15aab-6ad9-40a9-82a5-826f4724c89e', N'description2', N'unit2', NULL)
GO
INSERT [dbo].[Units] ([UID], [Description], [Name], [RowVersion]) VALUES (N'7e79b40a-1764-44e1-a774-8bdcc7c499f3', N'description1', N'unit1', NULL)
GO
USE [master]
GO
ALTER DATABASE [webapplication7] SET  READ_WRITE 
GO
