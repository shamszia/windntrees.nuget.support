﻿using System.Web.Mvc;
using WebApplication6.Repositories;
using WindnTrees.Abstraction.Controllers;
using WindnTrees.CRUDS.Repository;

namespace WebApplication6.Controllers
{
    public class EmployeeController : CRUDLController<Employee>
    {
        protected override CRUDLMRepository<Employee> GetRepository()
        {
            return new EmployeeRepository();
        }

        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }
    }
}