﻿using System.Linq;
using WindnTrees.CRUDS.Repository;
using WindnTrees.ICRUDS;

namespace WebApplication6.Repositories
{
    public class EmployeeRepository : EntityRepository<Employee>
    {
        public EmployeeRepository()
            : base(new windntreesEntities(), "")
        { }

        protected override IQueryable<Employee> QueryRecords(IQueryable<Employee> query, SearchInput queryObject = null)
        {
            queryObject.keyword = string.IsNullOrEmpty(queryObject.keyword) ? string.Empty : queryObject.keyword;
            query = query.Where(l => l.Name.Contains(queryObject.keyword) || l.Designation.Contains(queryObject.keyword));
            return query;
        }

        protected override IOrderedQueryable<Employee> SortRecords(IQueryable<Employee> query, SearchInput queryObject = null)
        {
            return query.OrderBy(l => l.Name);
        }
    }
}