﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Application.XForms.Models
{
    public enum MenuItemType
    {
        Browse,
        CRUDMethod,
        About
    }
    public class HomeMenuItem
    {
        public MenuItemType Id { get; set; }

        public string Title { get; set; }
    }
}
