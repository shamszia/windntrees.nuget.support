﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Application.XForms.Models;
using Application.XForms.Views;
using Application.XForms.ViewModels;
using WindnTrees.ICRUDS.Standard;
using WindnTrees.ICRUDS.Standard.Views;
using WindnTrees.ICRUDS.Standard.Processor;
using WindnTrees.ICRUDS.Standard.Controller;
using WindnTrees.ICRUDS.Standard.Model;
using System.Windows.Input;
using Android.Widget;

namespace Application.XForms.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CRUDMethod : ContentPage
    {
        #region CRUDView
        /// <summary>
        /// m_CRUDView, Category CRUDView data member.
        /// </summary>
        CRUDView<Category> m_CRUDView = null;
        /// <summary>
        /// CRUDView, property reference object.
        /// </summary>
        public CRUDView<Category> CRUDView
        {
            get
            {
                if (m_CRUDView == null)
                {
                    //Initialize CRUDView with protocol, ip, port, service name, service title, security status, controller type and page view model.
                    m_CRUDView = new CRUDView<Category>("http", "10.0.0.10", "80", "category", "category", false, ControllerType.HttpClientController, new CategoryViewModel());
                    m_CRUDView.OnViewModel += M_CRUDView_OnViewModel;
                    m_CRUDView.OnExceptionObject += M_CRUDView_OnExceptionObject;
                    m_CRUDView.OnMessage += M_CRUDView_OnMessage;
                }
                return m_CRUDView;
            }
        }

        /// <summary>
        /// OnViewModel, event handler.
        /// </summary>
        /// <param name="viewModel"></param>
        /// <param name="eventArgs"></param>
        private void M_CRUDView_OnViewModel(object viewModel, EventArgs eventArgs)
        {
            //Present view model object notified as a result of Create, Read, Update, Delete and List operations. 
            var categoryViewModel = (CategoryViewModel)viewModel;
            categoryViewModel.ListProcessing = false;
            categoryViewModel.ViewProcessing = false;
            MainThread.BeginInvokeOnMainThread(() =>
            {
                BindingContext = categoryViewModel;
            });
        }

        /// <summary>
        /// OnExceptionObject, event handler.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <param name="eventArgs"></param>
        private void M_CRUDView_OnExceptionObject(object contentObject, WindnTrees.ICRUDS.Standard.MethodEventArgs eventArgs)
        {
            //Display or process exceptions as a result of CRUDL operations.
            MainThread.BeginInvokeOnMainThread(() =>
            {
                Toast.MakeText(Android.App.Application.Context, eventArgs.ExceptionMessage, ToastLength.Short).Show();
            });
        }

        /// <summary>
        /// OnMessage, event handler.
        /// </summary>
        /// <param name="parameter"></param>
        private void M_CRUDView_OnMessage(object parameter)
        {
            //Display or process log messages reported as a result of CRUDL operations.
            MainThread.BeginInvokeOnMainThread(() =>
            {
                var message = ((ActionMessage)parameter).Message;
                Toast.MakeText(Android.App.Application.Context, message, ToastLength.Short).Show();
            });
        }
        #endregion

        /// <summary>
        /// Empty constructor.
        /// </summary>
        public CRUDMethod()
        {
            InitializeComponent();

            CRUDView.ResponseTypes.Add(new ResponseType { TargetMethod = "ListCategories", IsListResponse = true });
            CRUDView.ResponseTypes.Add(new ResponseType { TargetMethod = "ListAllCategories", IsListResponse = true });
            CRUDView.ResponseTypes.Add(new ResponseType { TargetMethod = "CreateCategory", IsListResponse = false });
        }

        /// <summary>
        /// ListItem_Clicked, gets category list items using CRUDMethod with target "ListCategories" on server side controller.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ListItem_Clicked(object sender, EventArgs e)
        {
            CRUDView.CRUDViewModel.ListProcessing = true;
            CRUDView.MethodObject(new SearchInput { keyword = "" }, "ListCategories");
        }

        /// <summary>
        /// ListAllItem_Clicked, gets all category list items using CRUDMethod with target "ListAllCategories" on server side controller.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ListAllItem_Clicked(object sender, EventArgs e)
        {
            CRUDView.CRUDViewModel.ListProcessing = true;
            CRUDView.Method("ListAllCategories");
        }

        /// <summary>
        /// AddItem_Clicked, creates new category using CRUDMethod MethodObject with input object and target "CreateCategory". Following invocation reports view model and does not update view.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void AddItem_Clicked(object sender, EventArgs e)
        {
            CRUDView.CRUDViewModel.ViewProcessing = true;
            CRUDView.CRUDViewModel.ContentModel = new Category { Uid = Guid.NewGuid(), Title = "Create 0", Description = "Description 0" };
            CRUDView.MethodObject(CRUDView.CRUDViewModel.ContentModel, "CreateCategory");
        }
    }
}