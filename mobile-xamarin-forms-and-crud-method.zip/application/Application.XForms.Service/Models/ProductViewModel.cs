﻿using System.Collections.Generic;
using WindnTreesSEO.Models.Database;

namespace WindnTreesSEO.Models
{
    /// <summary>
    /// ProductViewModel to demonstrate SEO content ready page.
    /// </summary>
    public class ProductViewModel
    {
        public List<Category> Categories;
        public List<Product> Top5Products;
        public List<Product> NewProducts;
    }
}