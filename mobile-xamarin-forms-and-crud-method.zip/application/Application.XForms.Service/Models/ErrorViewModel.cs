using System;

namespace WindnTreesSEO.Models
{
    /// <summary>
    /// ErrorViewModel for Error.cshtml view page.
    /// </summary>
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
