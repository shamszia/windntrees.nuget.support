﻿using System;
using System.Linq;
using System.Linq.Expressions;
using WindnTrees.CRUDS.Repository.Core;
using WindnTrees.ICRUDS.Standard;

namespace WindnTreesSEO.Models.Database.Repositories
{
    /// <summary>
    /// Category database repository.
    /// </summary>
    public class CategoryRepository : EntityRepository<Category>
    {
        /// <summary>
        /// Initializes database repository entitySet with application database context and related objects.
        /// </summary>
        /// <param name="dbContext"></param>
        /// <param name="relatedObjects"></param>
        public CategoryRepository(ApplicationContext dbContext, string relatedObjects = "")
            : base(dbContext, relatedObjects)
        { }

        /// <summary>
        /// Updates new Category with new id.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        protected override Category GenerateNewKey(Category contentObject)
        {
            contentObject.Uid = Guid.NewGuid();
            return contentObject;
        }

        /// <summary>
        /// Gets typed key value.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected override object GetTypedKey(object key)
        {
            return Guid.Parse((string)key);
        }

        /// <summary>
        /// Enables repository entitySet records input based selection.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="searchQuery"></param>
        /// <returns></returns>
        protected override IQueryable<Category> QueryRecords(IQueryable<Category> query, SearchInput searchQuery = null)
        {
            Expression<Func<Category, bool>> condition = null;
            if (!string.IsNullOrEmpty(searchQuery.keyword))
            {
                condition = l => (l.Title.Contains(searchQuery.keyword) || l.Description.Contains(searchQuery.keyword));
                query = query.Where(condition);
            }

            return query;
        }

        /// <summary>
        /// Enables repository entitySet records input based sorting.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="searchQuery"></param>
        /// <returns></returns>
        protected override IOrderedQueryable<Category> SortRecords(IQueryable<Category> query, SearchInput searchQuery = null)
        {
            IOrderedQueryable<Category> orderInterface = null;
            if (searchQuery.descend ==  null ? false : ((bool)searchQuery.descend))
            {
                orderInterface = query.OrderByDescending(l => l.Title);
            }
            else
            {
                orderInterface = query.OrderBy(l => l.Title);
            }
            return orderInterface;
        }
    }
}
