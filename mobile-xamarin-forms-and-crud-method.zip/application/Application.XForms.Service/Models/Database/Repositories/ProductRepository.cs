﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using WindnTrees.CRUDS.Repository.Core;
using WindnTrees.ICRUDS.Standard;

namespace WindnTreesSEO.Models.Database.Repositories
{
    /// <summary>
    /// Product database repository.
    /// </summary>
    public class ProductRepository : EntityRepository<Product>
    {
        /// <summary>
        /// Initializes database repository entitySet with application database context and related objects.
        /// </summary>
        /// <param name="dbContext"></param>
        /// <param name="relatedObjects"></param>
        public ProductRepository(ApplicationContext dbContext, string relatedObjects = "")
            : base(dbContext, relatedObjects)
        { }

        /// <summary>
        /// Updates new Product with new id.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        protected override Product GenerateNewKey(Product contentObject)
        {
            contentObject.Uid = Guid.NewGuid();
            return contentObject;
        }

        /// <summary>
        /// Gets typed key value.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected override object GetTypedKey(object key)
        {
            return Guid.Parse((string)key);
        }

        /// <summary>
        /// Enables repository entitySet records input based selection.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="searchQuery"></param>
        /// <returns></returns>
        protected override IQueryable<Product> QueryRecords(IQueryable<Product> query, SearchInput searchQuery = null)
        {
            Expression<Func<Product, bool>> condition = null;

            if (searchQuery.keys != null)
            {
                var categoryKey = ((List<SearchField>)searchQuery.keys).Where(l => l.field == "category").SingleOrDefault();
                if (categoryKey != null)
                {
                    if (!string.IsNullOrEmpty(categoryKey.value))
                    {
                        query = query.Where(l => l.Category.Equals(categoryKey.value));
                    }
                }
            }

            if (!string.IsNullOrEmpty(searchQuery.keyword))
            {
                condition = l => (l.Name.Contains(searchQuery.keyword) || l.Description.Contains(searchQuery.keyword));
                query = query.Where(condition);
            }

            return query;
        }

        /// <summary>
        /// Enables repository entitySet records input based sorting.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="searchQuery"></param>
        /// <returns></returns>
        protected override IOrderedQueryable<Product> SortRecords(IQueryable<Product> query, SearchInput searchQuery = null)
        {
            IOrderedQueryable<Product> orderInterface = null;
            if (searchQuery.descend ==  null ? false : ((bool)searchQuery.descend))
            {
                orderInterface = query.OrderByDescending(l => l.Name);
            }
            else
            {
                orderInterface = query.OrderBy(l => l.Name);
            }

            return orderInterface;
        }
    }
}
