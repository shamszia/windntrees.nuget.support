﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTrees.ICRUDS.Standard;
using WindnTreesSEO.Models.Database;
using WindnTreesSEO.Models.Database.Repositories;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace WindnTreesSEO.Controllers
{
    /// <summary>
    /// WindnTrees Category CRUD controller.
    /// </summary>
    public class CategoryController : CRUDLController<Category>
    {
        /// <summary>
        /// Gets entity framework application database context.
        /// </summary>
        /// <returns></returns>
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        /// <summary>
        /// Gets Category database repository.
        /// </summary>
        /// <returns></returns>
        protected override EntityRepository<Category> GetRepository()
        {
            return new CategoryRepository((ApplicationContext)GetDBContext());
        }

        #region CRUDMethod_Controller_Actions
        /// <summary>
        /// CreateCategory controller action method for creation of new category using CRUDMethod by CRUD client.
        /// </summary>
        /// <param name="contentCategory"></param>
        /// <returns></returns>
        public JsonResult CreateCategory([FromBody] Category contentCategory)
        {
            return base.Create(contentCategory);
        }

        /// <summary>
        /// ListCategories controller action method for listing top 5 categories using CRUDMethod by CRUD client.
        /// </summary>
        /// <param name="webInput"></param>
        /// <returns></returns>
        public JsonResult ListCategories([FromBody] WebInput webInput)
        {
            var top5Categories = new List<Category>();
            top5Categories.Add(new Category { Uid = Guid.NewGuid(), Title = "Top 1 Category", Description = "" });
            top5Categories.Add(new Category { Uid = Guid.NewGuid(), Title = "Top 2 Category", Description = "" });
            top5Categories.Add(new Category { Uid = Guid.NewGuid(), Title = "Top 3 Category", Description = "" });
            top5Categories.Add(new Category { Uid = Guid.NewGuid(), Title = "Top 4 Category", Description = "" });
            top5Categories.Add(new Category { Uid = Guid.NewGuid(), Title = "Top 5 Category", Description = "" });
            return GetContentListResult(top5Categories, top5Categories.Count);
        }

        /// <summary>
        /// ListAllCategories controller action method for listing all categories using CRUDMethod by CRUD client.
        /// </summary>
        /// <returns></returns>
        public JsonResult ListAllCategories()
        {
            return base.List(new WebInput { keyword = "" });
        } 
        #endregion
    }
}