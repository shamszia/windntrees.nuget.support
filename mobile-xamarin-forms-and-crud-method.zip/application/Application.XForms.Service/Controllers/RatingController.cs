﻿using Microsoft.EntityFrameworkCore;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTreesSEO.Models.Database;
using WindnTreesSEO.Models.Database.Repositories;

namespace WindnTreesSEO.Controllers
{
    /// <summary>
    /// WindnTrees Rating CRUD controller.
    /// </summary>
    public class RatingController : CRUDLController<Rating>
    {
        /// <summary>
        /// Gets entity framework application database context.
        /// </summary>
        /// <returns></returns>
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        /// <summary>
        /// Gets Product database repository.
        /// </summary>
        /// <returns></returns>
        protected override EntityRepository<Rating> GetRepository()
        {
            return new RatingRepository((ApplicationContext)GetDBContext());
        }
    }
}