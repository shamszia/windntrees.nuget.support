﻿using Microsoft.EntityFrameworkCore;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTreesSEO.Models.Database.Repositories;
using WindnTreesSEO.Models.Database;
using Microsoft.AspNetCore.Mvc;
using System;
using WindnTrees.ICRUDS.Standard;

namespace WindnTreesSEO.Controllers
{
    /// <summary>
    /// WindnTrees Topic CRUD controller.
    /// </summary>
    public class TopicController : CRUDLController<Topic>
    {
        /// <summary>
        /// Gets entity framework application database context.
        /// </summary>
        /// <returns></returns>
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        /// <summary>
        /// Gets Topic database repository.
        /// </summary>
        /// <returns></returns>
        protected override EntityRepository<Topic> GetRepository()
        {
            return new TopicRepository((ApplicationContext)GetDBContext());
        }

        /// <summary>
        /// Creates a new topic.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public override JsonResult Create([FromBody] Topic contentObject)
        {
            return base.Create(contentObject);
        }

        /// <summary>
        /// Updates an existing topic.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public override JsonResult Update([FromBody] Topic contentObject)
        {
            return base.Update(contentObject);
        }

        /// <summary>
        /// Deletes an existing topic.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public override JsonResult Delete([FromBody] Topic contentObject)
        {
            return base.Delete(contentObject);
        }

        /// <summary>
        /// List topics.
        /// </summary>
        /// <param name="webInput"></param>
        /// <returns></returns>
        public override JsonResult List([FromBody] WebInput webInput)
        {
            return base.List(webInput);
        }
    }
}