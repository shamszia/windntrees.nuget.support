﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTreesSEO.Models.Database.Repositories;
using WindnTreesSEO.Models.Database;
using WindnTreesSEO.Models;
using System;

namespace WindnTreesSEO.Controllers
{
    /// <summary>
    /// WindnTrees Product CRUD controller.
    /// </summary>
    public class ProductController : CRUDLController<Product>
    {
        /// <summary>
        /// Gets entity framework application database context.
        /// </summary>
        /// <returns></returns>
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        /// <summary>
        /// Gets Product database repository.
        /// </summary>
        /// <returns></returns>
        protected override EntityRepository<Product> GetRepository()
        {
            return new ProductRepository((ApplicationContext)GetDBContext());
        }
    }
}
