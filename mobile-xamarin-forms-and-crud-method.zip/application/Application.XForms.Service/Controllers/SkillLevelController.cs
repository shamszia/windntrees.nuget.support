﻿using Microsoft.EntityFrameworkCore;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTreesSEO.Models.Database.Repositories;
using WindnTreesSEO.Models.Database;

namespace WindnTreesSEO.Controllers
{
    /// <summary>
    /// WindnTrees SkillLevel CRUD controller.
    /// </summary>
    public class SkillLevelController : CRUDLController<SkillLevel>
    {
        /// <summary>
        /// Gets entity framework application database context.
        /// </summary>
        /// <returns></returns>
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        /// <summary>
        /// Gets Product database repository.
        /// </summary>
        /// <returns></returns>
        protected override EntityRepository<SkillLevel> GetRepository()
        {
            return new SkillLevelRepository((ApplicationContext)GetDBContext());
        }
    }
}