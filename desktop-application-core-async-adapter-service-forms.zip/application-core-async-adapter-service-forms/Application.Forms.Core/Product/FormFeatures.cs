﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Application.Models.Standard.DataAccess.Adapter;

namespace ApplicationForms.Core.Product
{
    public partial class FormFeatures : Form
    {
        public List<ProductFeature> GetFeatures
        {
            get
            {
                try
                {
                    ProductFeature[] productFeaturesArray = new ProductFeature[bindingSourceFeatures.List.Count];
                    bindingSourceFeatures.List.CopyTo(productFeaturesArray, 0);
                    return new List<ProductFeature>(productFeaturesArray);
                }
                catch(Exception ex)
                {
                    throw ex;
                }
            }
        }

        public void SetFeatures(ProductFeature[] productFeaturesArray)
        {
            bindingSourceFeatures.DataSource = new List<ProductFeature>(productFeaturesArray);
        }

        public FormFeatures()
        {
            InitializeComponent();
        }

        private void dataGridViewFeatures_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    if (e.ColumnIndex == 0)
                    {
                        dataGridViewFeatures.CurrentCell.Value = Guid.NewGuid();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}