USE [master]
GO
/****** Object:  Database [tutorials]    Script Date: 11/15/2020 1:24:24 PM ******/
CREATE DATABASE [tutorials]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'tutorials', FILENAME = N'D:\projects\documents\windntrees\tutorials\db\tutorials.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'tutorials_log', FILENAME = N'D:\projects\documents\windntrees\tutorials\db\tutorials_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [tutorials] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [tutorials].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [tutorials] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [tutorials] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [tutorials] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [tutorials] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [tutorials] SET ARITHABORT OFF 
GO
ALTER DATABASE [tutorials] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [tutorials] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [tutorials] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [tutorials] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [tutorials] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [tutorials] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [tutorials] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [tutorials] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [tutorials] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [tutorials] SET  DISABLE_BROKER 
GO
ALTER DATABASE [tutorials] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [tutorials] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [tutorials] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [tutorials] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [tutorials] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [tutorials] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [tutorials] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [tutorials] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [tutorials] SET  MULTI_USER 
GO
ALTER DATABASE [tutorials] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [tutorials] SET DB_CHAINING OFF 
GO
ALTER DATABASE [tutorials] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [tutorials] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [tutorials] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [tutorials] SET QUERY_STORE = OFF
GO
USE [tutorials]
GO
/****** Object:  User [windntrees]    Script Date: 11/15/2020 1:24:25 PM ******/
CREATE USER [windntrees] FOR LOGIN [windntrees] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [windntrees]
GO
/****** Object:  Table [dbo].[Category]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Category](
	[UID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](200) NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[UID] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Designation] [nvarchar](100) NULL,
	[Salary] [decimal](18, 2) NULL,
	[Allowance] [decimal](18, 2) NULL,
	[Email] [nvarchar](450) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[UID] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](1024) NULL,
	[Version] [nvarchar](100) NULL,
	[Code] [nvarchar](100) NULL,
	[LegalCode] [nvarchar](100) NULL,
	[ProductYear] [int] NULL,
	[Category] [nvarchar](50) NULL,
	[Manufacturer] [nvarchar](50) NULL,
	[Unit] [nvarchar](50) NULL,
	[Color] [nvarchar](50) NULL,
	[Service] [bit] NULL,
	[Picture] [nvarchar](50) NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_Product_1] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductFeature]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductFeature](
	[UID] [uniqueidentifier] NOT NULL,
	[ProductID] [uniqueidentifier] NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_ProductFeatures] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Rating]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Rating](
	[UID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](200) NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_Rating] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SkillLevel]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SkillLevel](
	[UID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](200) NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_Skill] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Topic]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Topic](
	[UID] [uniqueidentifier] NOT NULL,
	[CategoryID] [uniqueidentifier] NOT NULL,
	[SkillLevelID] [uniqueidentifier] NULL,
	[RecordTime] [datetime] NOT NULL,
	[Menu] [nvarchar](100) NULL,
	[Subject] [nvarchar](200) NOT NULL,
	[Description1] [ntext] NULL,
	[Description2] [ntext] NULL,
	[Active] [bit] NULL,
	[UpdateTime] [datetime] NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_Topic] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TopicRating]    Script Date: 11/15/2020 1:24:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TopicRating](
	[UID] [uniqueidentifier] NOT NULL,
	[TopicID] [uniqueidentifier] NULL,
	[RatingID] [uniqueidentifier] NULL,
	[RowVersion] [timestamp] NULL,
 CONSTRAINT [PK_TopicRating] PRIMARY KEY CLUSTERED 
(
	[UID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Category] ([UID], [Title], [Description]) VALUES (N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'Authorization', N'')
GO
INSERT [dbo].[Category] ([UID], [Title], [Description]) VALUES (N'3aac09d8-8fc1-411a-b46a-2067818de1c3', N'Engineering', NULL)
GO
INSERT [dbo].[Category] ([UID], [Title], [Description]) VALUES (N'a6a94c1e-1dec-48ea-907e-97cecc757847', N'Authentication', NULL)
GO
INSERT [dbo].[Category] ([UID], [Title], [Description]) VALUES (N'60add597-9a41-4cff-ad18-d0de32633f92', N'General', NULL)
GO
INSERT [dbo].[Category] ([UID], [Title], [Description]) VALUES (N'3270a54d-8187-4a6f-8b98-d9621c018089', N'Development', N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'43006481-ad81-4e86-a488-0a51cf9b435b', N'Product 43', N'-', N'1', N'Product 43', N'Product 43', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'0d0d4778-a92e-45ae-92b9-0a87800feb5a', N'Product 44', N'-', N'1', N'Product 43', N'Product 43', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'8198ccb1-4d42-4fb3-9ef1-1aa40b93e56f', N'Product 14', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'58f4297a-0870-4739-b4dd-21b410ec4846', N'Product 5', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'39017352-6986-4dbf-9a52-2db501e4a466', N'Get Started with Programming 1', NULL, NULL, NULL, NULL, 2020, N'General', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'aed10173-5535-4848-865b-30cc914a351b', N'Product 41', N'-', N'1', N'Product 41', N'Product 41', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'e2e6b7dc-2417-4415-a414-3793c40f6391', N'Product 10', N'update', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'394f9a58-31bc-4f31-ac0b-3a12afe4f267', N'Product 20', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'f11ad322-31ac-4158-ad01-3e874669ca13', N'Product 24', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'40e3c068-0c35-49d5-9dc3-42df1b669c2c', N'Product 42', NULL, N'1', N'Product 42', N'Product 42', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'42e5f977-ba74-4901-8aaf-452a732bfabb', N'Security Series Course 3', N'-', NULL, NULL, NULL, 2020, N'Authentication', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'bd0462ed-b995-432a-87e3-4759dca96250', N'Product 31', NULL, NULL, N'Product 28', NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'660dfff5-a12a-4581-ad6f-4c1634f81859', N'Get started with programming', N'-', NULL, NULL, NULL, 2020, N'Authorization', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'b31e91dd-3fce-4344-9f13-4c9189eb3ad2', N'Product 28', NULL, NULL, N'Product 28', NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'256810df-2841-4e4b-9b1c-510ce1268092', N'Product 9', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'9e181063-1ffa-43d0-9be9-59061a96aab9', N'Product 23', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'213d9a5d-f993-4105-8046-63302119897a', N'Product 1', N'-', N'1', N'Product 1', N'Product 1', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'3f96a991-6d90-4125-aca6-754b9b0ba1bd', N'Product 40', N'-', N'1', N'Product 40', N'Product 40', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'fa2d085d-a64e-42b0-9e90-7a0035fbf522', N'Product 21', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'7efbe5e1-59b2-448c-a615-7c7a6c64c519', N'Product 18', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'6a017272-9c9c-4adc-8cb1-7df5fe1fd7d8', N'Get Started with Programming 2', N'-', NULL, NULL, NULL, 2020, N'General', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'5ddb4706-97d6-4125-afae-87ecad4418b6', N'Product 4', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'2d7c7f76-4e21-436f-8c6b-9057429b60c2', N'Get Started with Programming 3', N'-', NULL, NULL, NULL, 2020, N'General', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'62399935-e9a0-41f8-a48c-983a9eac6d2a', N'Product 22', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'7a004400-b8b3-446e-8808-9f2b7f960fa2', N'Product 15', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'5440911e-f460-4cb8-9680-aac62d59e3fe', N'Product 17', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'e40b7fcd-b566-4c72-8298-b7a7d2ab15a0', N'Web security tutorial course 1', N'-', NULL, NULL, NULL, 2020, N'Authorization', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'54613926-bde2-4e7e-95a2-bcfdddc321af', N'Product 19', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'8f0954fc-1960-49a8-9b82-c01d9a06f6ab', N'Product 29', NULL, NULL, N'Product 28', NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'6f5780bd-356c-4ef7-8eb6-c0e2f9d9a46e', N'Security Series Course 2', N'-', NULL, NULL, NULL, 2020, N'Authorization', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'cb6572b8-5215-4cf7-8303-c3daf7f3be7d', N'Product 6', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'8aa9507e-9e14-4ca5-bc8d-c4f6f4b70be4', N'Product 13', N'-', N'1', N'Product 13', N'Product 13', 2020, N'-', N'-', N'-', N'-', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'b36f0fbe-7873-4810-99cb-c64570d11a5a', N'Get Start with Programming 1', N'', NULL, NULL, NULL, 2020, N'Authentication', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'a88d09ff-3dc3-4574-9385-d4306139bbb4', N'Product 16', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'8b0bf96c-3a9b-40bf-97bb-d86c2b631c08', N'Security Series Course 1', N'-', NULL, NULL, NULL, 2020, N'Authentication', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'bab4c260-c913-46f3-9b73-d9411a4ebd43', N'Product 7', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'2c1eeb8f-026a-4923-9fad-e8d3e6916d24', N'Product 41', N'-', N'1', N'Product 41', N'Product 41', 2020, N'-', N'-', N'-', N'-', NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'ed290a4d-fa0b-42e7-970b-ed5058616488', N'Get Started with Programming 4', N'-', NULL, NULL, NULL, 2020, N'General', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'2b2c4686-e7b5-4bb6-af8f-f1f134fc39b1', N'Product 28', NULL, NULL, NULL, NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'938ed177-a59d-4122-b8d1-f285aff10fb3', N'Product 32', NULL, NULL, N'Product 28', NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'e6b806e7-c5d5-430d-bf33-fc6a5e346f41', N'Product 3', N'', N'', N'', N'', 2020, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Product] ([UID], [Name], [Description], [Version], [Code], [LegalCode], [ProductYear], [Category], [Manufacturer], [Unit], [Color], [Service], [Picture]) VALUES (N'08f51ec2-f595-4336-8d33-ffe7934f0a2a', N'Product 30', NULL, NULL, N'Product 28', NULL, 2020, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'617f759c-5c56-4641-9cf6-1a0b03783478', N'aed10173-5535-4848-865b-30cc914a351b', N'Feature 3', N'Description 3')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'ec4ad9dd-2a86-4bb2-b9d0-374f153cb1a0', NULL, N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'2a5c4cce-154f-488e-a2df-395b6da310f1', N'aed10173-5535-4848-865b-30cc914a351b', N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'0408dc93-2f63-4571-b91e-3b67b089fa0e', N'2c1eeb8f-026a-4923-9fad-e8d3e6916d24', N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'bf49d6c0-ad53-408b-b36a-3c9e6e19b7b7', N'40e3c068-0c35-49d5-9dc3-42df1b669c2c', N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'9d359d78-23f8-406a-aeb8-3ccec16371b4', N'aed10173-5535-4848-865b-30cc914a351b', N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'7c9fdd6b-5531-46fe-aed0-4cc4ae6a9d10', NULL, N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'4b13b851-0800-41a8-9f4f-52662a1bc665', NULL, N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'27beb45b-8ac2-419a-a0bb-5d462ec5f9fb', NULL, N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'c92f8d10-5065-41d8-aa18-6a10c6433bad', N'0d0d4778-a92e-45ae-92b9-0a87800feb5a', N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'40f7cfa8-ed05-416e-a019-70c737539391', N'8aa9507e-9e14-4ca5-bc8d-c4f6f4b70be4', N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'ab6925b3-fe71-430b-91a6-929828a37ea0', NULL, N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'a81decd2-01fe-4d1b-a6d9-9b7171945726', N'0d0d4778-a92e-45ae-92b9-0a87800feb5a', N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'021099bb-fef5-4460-8630-aa987a20d17b', N'2c1eeb8f-026a-4923-9fad-e8d3e6916d24', N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'54355307-87d4-4d55-a529-abc3a0dd8a14', NULL, N'Feature 3', N'Description 3')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'53adf0fe-f6bf-4609-8ad0-ad7f12b859ff', N'40e3c068-0c35-49d5-9dc3-42df1b669c2c', N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'b6d24122-1f7c-429b-a31c-b3394807723d', NULL, N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'7d3f7a17-181d-4c24-8d26-b4bb769d12f8', NULL, N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'e4fb3f2e-bd5a-47cf-901a-b6a7d013f141', NULL, N'Feature 1', N'Description 1')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'def6e9f3-d82b-4061-9ab5-ba2a67c95e0a', NULL, N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'b4fef809-e105-4fd7-9cf9-da2deca59ff2', NULL, N'Feature 3', N'Description 3')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'54500e1e-b3e2-4f64-8ae5-ec14ebc3d97c', NULL, N'Feature 2', N'Description 2')
GO
INSERT [dbo].[ProductFeature] ([UID], [ProductID], [Name], [Description]) VALUES (N'dc6cf840-a617-4095-9672-edf442b2b7a5', N'213d9a5d-f993-4105-8046-63302119897a', N'Feature 1', N'Description 1')
GO
INSERT [dbo].[Rating] ([UID], [Title], [Description]) VALUES (N'99d657b3-f734-453a-95b0-1b93fc326d9b', N'Average', NULL)
GO
INSERT [dbo].[Rating] ([UID], [Title], [Description]) VALUES (N'c5b906b5-408a-461e-8456-1faa7c01b358', N'Good', NULL)
GO
INSERT [dbo].[Rating] ([UID], [Title], [Description]) VALUES (N'ae7cfe8c-1a3d-47af-ad55-d4b3ddeda2c1', N'Poor', NULL)
GO
INSERT [dbo].[SkillLevel] ([UID], [Title], [Description]) VALUES (N'4ed3c763-1f78-4229-92e3-86d3db2f4bc8', N'Advance', NULL)
GO
INSERT [dbo].[SkillLevel] ([UID], [Title], [Description]) VALUES (N'd1da091a-082a-4341-9222-899f81e77043', N'Intermediate', NULL)
GO
INSERT [dbo].[SkillLevel] ([UID], [Title], [Description]) VALUES (N'4aaa255f-b0e7-45dc-be1f-ffe16aa5523f', N'Beginner', NULL)
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'6d88a27b-3277-490c-abd8-01845120657d', N'60add597-9a41-4cff-ad18-d0de32633f92', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2019-09-21T12:33:32.293' AS DateTime), N'Application -> Settings', N'Enter subject here.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2019-09-21T12:33:32.293' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'3ff2f44e-ecf3-47bc-9f27-163f090d10b4', N'60add597-9a41-4cff-ad18-d0de32633f92', N'4aaa255f-b0e7-45dc-be1f-ffe16aa5523f', CAST(N'2019-09-20T11:54:27.797' AS DateTime), N'Application -> Topic', N'New topic subject here', N'Enter description here.', N'Enter description here.', 1, CAST(N'2019-09-20T11:54:27.797' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'd61c3b20-b82b-4934-83e5-53159e9fd026', N'a6a94c1e-1dec-48ea-907e-97cecc757847', N'4ed3c763-1f78-4229-92e3-86d3db2f4bc8', CAST(N'2020-11-07T09:20:43.440' AS DateTime), N'Application -> Authentication', N'Subject here', N'Description 1', N'Description 2', 1, CAST(N'2020-11-07T09:20:43.440' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'85334e23-3133-4300-9a51-69e4b665abd1', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2019-09-23T09:51:45.097' AS DateTime), N'Application -> Settings', N'Enter subject here.', N'Enter authorization value here.', N'Enter authorization description here.', 1, CAST(N'2019-09-23T09:51:45.097' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'f2dc4fb7-40ca-444f-81de-7deec18a1780', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2020-11-07T09:31:15.857' AS DateTime), N'Application -> Authorization', N'Enter authorization subject here.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2020-11-07T09:31:15.857' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'dc8a08a9-3a32-4ac5-8d74-a65b714fa328', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2020-11-07T09:21:42.030' AS DateTime), N'Application -> Authorization', N'Enter authorization subject here. update.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2020-11-07T09:21:42.030' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'695b2756-6ec0-42bc-ab79-b9ba80e6a106', N'60add597-9a41-4cff-ad18-d0de32633f92', N'4aaa255f-b0e7-45dc-be1f-ffe16aa5523f', CAST(N'2019-09-23T10:05:55.090' AS DateTime), N'Application -> Menu', N'Enter subject here.', N'Enter description 1 here.', N'Enter description 2 here.', 1, CAST(N'2019-09-23T10:05:55.090' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'20428048-20f9-4321-9fd7-bbfa5acbabb3', N'a6a94c1e-1dec-48ea-907e-97cecc757847', N'4ed3c763-1f78-4229-92e3-86d3db2f4bc8', CAST(N'2020-11-07T09:30:38.333' AS DateTime), N'Application -> Topics', N'Topic subject here', N'Description 1', N'Description 2', 1, CAST(N'2020-11-07T09:30:38.333' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'49e57e40-7223-4184-8f8c-c71155f8884e', N'a6a94c1e-1dec-48ea-907e-97cecc757847', N'4aaa255f-b0e7-45dc-be1f-ffe16aa5523f', CAST(N'2019-09-23T09:50:43.227' AS DateTime), N'Application -> Settings', N'Enter subject here', N'Enter description here.', N'Enter description here.', 1, CAST(N'2019-09-23T09:50:43.227' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'fbe96943-2d59-49f8-baec-cf2d4fdbb289', N'a6a94c1e-1dec-48ea-907e-97cecc757847', N'4ed3c763-1f78-4229-92e3-86d3db2f4bc8', CAST(N'2019-09-23T09:49:59.260' AS DateTime), N'Application -> Settings', N'Enter subject here.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2019-09-23T09:49:59.260' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'c459ec2d-3fde-400a-adc6-dd2c0faee547', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2020-11-07T09:21:13.593' AS DateTime), N'Application -> Authorization', N'Enter authorization subject here. update.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2020-11-07T09:21:13.593' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'3f83bd3d-ea94-4d4c-8012-edb58e14cc32', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2020-11-07T09:30:52.747' AS DateTime), N'Application -> Authorization', N'Enter authorization subject here.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2020-11-07T09:30:52.747' AS DateTime))
GO
INSERT [dbo].[Topic] ([UID], [CategoryID], [SkillLevelID], [RecordTime], [Menu], [Subject], [Description1], [Description2], [Active], [UpdateTime]) VALUES (N'c474d0b5-6dd8-4f13-b1c0-f8592f83bef0', N'e0ef3f90-59fe-4e3e-9edb-0ad3a1db71a1', N'd1da091a-082a-4341-9222-899f81e77043', CAST(N'2020-11-07T09:44:43.780' AS DateTime), N'Application -> Authorization', N'Enter authorization subject here.', N'Enter description here.', N'Enter description here.', 1, CAST(N'2020-11-07T09:44:43.780' AS DateTime))
GO
ALTER TABLE [dbo].[ProductFeature]  WITH CHECK ADD  CONSTRAINT [FK_ProductFeature_Product] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Product] ([UID])
ON UPDATE SET NULL
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[ProductFeature] CHECK CONSTRAINT [FK_ProductFeature_Product]
GO
ALTER TABLE [dbo].[Topic]  WITH CHECK ADD  CONSTRAINT [FK_Topic_Category] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[Category] ([UID])
GO
ALTER TABLE [dbo].[Topic] CHECK CONSTRAINT [FK_Topic_Category]
GO
ALTER TABLE [dbo].[Topic]  WITH CHECK ADD  CONSTRAINT [FK_Topic_SkillLevel] FOREIGN KEY([SkillLevelID])
REFERENCES [dbo].[SkillLevel] ([UID])
GO
ALTER TABLE [dbo].[Topic] CHECK CONSTRAINT [FK_Topic_SkillLevel]
GO
ALTER TABLE [dbo].[TopicRating]  WITH CHECK ADD  CONSTRAINT [FK_TopicRating_Rating] FOREIGN KEY([RatingID])
REFERENCES [dbo].[Rating] ([UID])
GO
ALTER TABLE [dbo].[TopicRating] CHECK CONSTRAINT [FK_TopicRating_Rating]
GO
ALTER TABLE [dbo].[TopicRating]  WITH CHECK ADD  CONSTRAINT [FK_TopicRating_Topic] FOREIGN KEY([TopicID])
REFERENCES [dbo].[Topic] ([UID])
GO
ALTER TABLE [dbo].[TopicRating] CHECK CONSTRAINT [FK_TopicRating_Topic]
GO
USE [master]
GO
ALTER DATABASE [tutorials] SET  READ_WRITE 
GO
