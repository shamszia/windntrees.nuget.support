﻿using SharedLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using WindnTrees.ICRUDS.Standard;

namespace ConsoleAppNETCoreFramework.CRUDS
{
    public class AdapterClient
    {
        int m_passed = 0;
        int m_failed = 0;
        int m_timeout = 5;
        bool m_secured = false;

        public bool Secured
        {
            get
            {
                return m_secured;
            }

            set
            {
                m_HttpServiceClient = null;
                m_HttpWCFServiceClient = null;
                m_TCPServiceClient = null;
                m_TCPWCFServiceClient = null;
                m_secured = value;
            }
        }

        SharedLibrary.Model.Adapter.Product m_CreatedObject = null;
        SharedLibrary.Model.Adapter.Product m_ReadObject = null;
        SharedLibrary.Model.Adapter.Product m_UpdatedObject = null;
        SharedLibrary.Model.Adapter.Product m_DeletedObject = null;
        List<SharedLibrary.Model.Adapter.Product> m_ListObjects = null;
        SharedLibrary.Model.Adapter.Product m_MethodObject = null;
        SharedLibrary.Model.Adapter.Product m_MethodContentObject = null;
        SharedLibrary.Model.Adapter.Product m_WcfMethodContent = null;
        List<SharedLibrary.Model.Adapter.Product> m_WcfMethodContentList = null;
        SharedLibrary.Model.Adapter.Product m_WcfMethodSearchContent = null;
        List<SharedLibrary.Model.Adapter.Product> m_WcfMethodSearchList = null;

        public List<TestReport> m_TestReports = new List<TestReport>();

        #region HttpServiceClient
        private ServiceClient<SharedLibrary.Model.Adapter.Product> m_HttpServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private ServiceClient<SharedLibrary.Model.Adapter.Product> HttpServiceClient
        {
            get
            {
                if (m_HttpServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_HttpServiceClient = new ServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetBasicHttpChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("https", "127.0.0.1", "8085", "secure/product"), m_secured));
                    }
                    else
                    {
                        m_HttpServiceClient = new ServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetBasicHttpChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("http", "127.0.0.1", "8084", "product")));
                    }
                    
                    m_HttpServiceClient.OnMessage += M_HttpServiceClient_OnMessage;
                    m_HttpServiceClient.OnContentObject += M_HttpServiceClient_OnContentObject;
                    m_HttpServiceClient.OnContentObjectList += M_HttpServiceClient_OnContentObjectList;
                }
                return m_HttpServiceClient;
            }
        }

        private void M_HttpServiceClient_OnMessage(object message)
        {

        }

        private void M_HttpServiceClient_OnContentObjectList(List<SharedLibrary.Model.Adapter.Product> contentObjectList, MethodEventArgs eventArgs)
        {
            var caption = "ListAsync";

            if (eventArgs.Exception)
            {
                m_failed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                m_TestReports.Add(new TestReport
                {
                    Id = "http_ListAsync",
                    Name = "ListAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }
            else
            {
                m_passed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} OK.", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = "http_ListAsync",
                    Name = "ListAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
        }

        private void M_HttpServiceClient_OnContentObject(object contentObject, MethodEventArgs eventArgs)
        {
            string caption = "";

            if (eventArgs.MethodType == MethodType.CreateAsync)
            {
                caption = "CreateAsync";
            }
            else if (eventArgs.MethodType == MethodType.ReadAsync)
            {
                caption = "ReadAsync";
            }
            else if (eventArgs.MethodType == MethodType.UpdateAsync)
            {
                caption = "UpdateAsync";
            }
            else if (eventArgs.MethodType == MethodType.DeleteAsync)
            {
                caption = "DeleteAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodAsync)
            {
                caption = "MethodAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
            {
                caption = "MethodObjectAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
            {
                caption = "MethodSearchAsync";
            }

            if (eventArgs.Exception)
            {
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_failed += 4;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "CreateAsync"),
                        Name = "CreateAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_failed += 3;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_failed += 2;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_failed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", caption),
                        Name = caption,
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_CreatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_ReadObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_UpdatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.DeleteAsync)
                {
                    m_DeletedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodAsync)
                {
                    m_MethodObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
                {
                    m_MethodContentObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }

                m_passed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} OK", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", caption),
                    Name = caption,
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #region HttpWCFServiceClient
        private WCFServiceClient<SharedLibrary.Model.Adapter.Product> m_HttpWCFServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private WCFServiceClient<SharedLibrary.Model.Adapter.Product> HttpWCFServiceClient
        {
            get
            {
                if (m_HttpWCFServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_HttpWCFServiceClient = new WCFServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetBasicHttpWCFChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("https", "127.0.0.1", "8085", "secure/product/wcf"), m_secured));
                    }
                    else
                    {
                        m_HttpWCFServiceClient = new WCFServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetBasicHttpWCFChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("http", "127.0.0.1", "8084", "product/wcf")));
                    }
                    
                    m_HttpWCFServiceClient.OnMessage += M_HttpWCFServiceClient_OnMessage;
                    m_HttpWCFServiceClient.OnContentObject += M_HttpWCFServiceClient_OnContentObject;
                    m_HttpWCFServiceClient.OnContentObjectList += M_HttpWCFServiceClient_OnContentObjectList;
                }
                return m_HttpWCFServiceClient;
            }
        }

        private void M_HttpWCFServiceClient_OnMessage(object message)
        {

        }

        private void M_HttpWCFServiceClient_OnContentObjectList(List<SharedLibrary.Model.Adapter.Product> contentObjectList, MethodEventArgs eventArgs)
        {
            string caption = null;

            if (eventArgs.MethodType == MethodType.ListAsync)
            {
                caption = "ListAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodContentListAsync)
            {
                caption = "MethodContentListAsync";
                m_WcfMethodContentList = contentObjectList;
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchListAsync)
            {
                caption = "MethodSearchListAsync";
                m_WcfMethodSearchList = contentObjectList;
            }

            if (eventArgs.Exception)
            {
                m_failed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", caption),
                    Name = caption,
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }
            else
            {
                m_passed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} OK.", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", caption),
                    Name = caption,
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
        }

        private void M_HttpWCFServiceClient_OnContentObject(object contentObject, MethodEventArgs eventArgs)
        {
            string caption = "";

            if (eventArgs.MethodType == MethodType.CreateAsync)
            {
                caption = "CreateAsync";
            }
            else if (eventArgs.MethodType == MethodType.ReadAsync)
            {
                caption = "ReadAsync";
            }
            else if (eventArgs.MethodType == MethodType.UpdateAsync)
            {
                caption = "UpdateAsync";
            }
            else if (eventArgs.MethodType == MethodType.DeleteAsync)
            {
                caption = "DeleteAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodAsync)
            {
                caption = "MethodAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
            {
                caption = "MethodObjectAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodContentAsync)
            {
                caption = "MethodContentAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
            {
                caption = "MethodSearchAsync";
            }


            if (eventArgs.Exception)
            {
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_failed += 4;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "CreateAsync"),
                        Name = "CreateAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_failed += 3;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_failed += 2;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_failed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", caption),
                        Name = caption,
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_CreatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_ReadObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_UpdatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.DeleteAsync)
                {
                    m_DeletedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodAsync)
                {
                    m_MethodObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
                {
                    m_MethodContentObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodContentAsync)
                {
                    m_WcfMethodContent = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
                {
                    m_WcfMethodSearchContent = (SharedLibrary.Model.Adapter.Product)contentObject;
                }


                m_passed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} OK", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", caption),
                    Name = caption,
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #region TCPServiceClient
        private ServiceClient<SharedLibrary.Model.Adapter.Product> m_TCPServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private ServiceClient<SharedLibrary.Model.Adapter.Product> TCPServiceClient
        {
            get
            {
                if (m_TCPServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_TCPServiceClient = new ServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetTcpChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("net.tcp", "127.0.0.1", "8087", "secure/product"), m_secured));
                    }
                    else
                    {
                        m_TCPServiceClient = new ServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetTcpChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("net.tcp", "127.0.0.1", "8086", "product")));
                    }
                    
                    m_TCPServiceClient.OnMessage += M_TCPServiceClient_OnMessage;
                    m_TCPServiceClient.OnContentObject += M_TCPServiceClient_OnContentObject;
                    m_TCPServiceClient.OnContentObjectList += M_TCPServiceClient_OnContentObjectList;
                }
                return m_TCPServiceClient;
            }
        }

        private void M_TCPServiceClient_OnMessage(object message)
        {

        }

        private void M_TCPServiceClient_OnContentObjectList(List<SharedLibrary.Model.Adapter.Product> contentObjectList, MethodEventArgs eventArgs)
        {
            var caption = "ListAsync";

            if (eventArgs.Exception)
            {
                m_failed++;
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine(eventArgs.ExceptionMessage);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", caption),
                    Name = caption,
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }
            else
            {
                m_passed++;
                Console.WriteLine(string.Format("{0} OK.", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", caption),
                    Name = caption,
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
        }

        private void M_TCPServiceClient_OnContentObject(object contentObject, MethodEventArgs eventArgs)
        {
            string caption = "";

            if (eventArgs.MethodType == MethodType.CreateAsync)
            {
                caption = "CreateAsync";
            }
            else if (eventArgs.MethodType == MethodType.ReadAsync)
            {
                caption = "ReadAsync";
            }
            else if (eventArgs.MethodType == MethodType.UpdateAsync)
            {
                caption = "UpdateAsync";
            }
            else if (eventArgs.MethodType == MethodType.DeleteAsync)
            {
                caption = "DeleteAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodAsync)
            {
                caption = "MethodAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
            {
                caption = "MethodObjectAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
            {
                caption = "MethodSearchAsync";
            }

            if (eventArgs.Exception)
            {
                m_failed++;
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_failed += 4;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "CreateAsync"),
                        Name = "CreateAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_failed += 3;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_failed += 2;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_failed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", caption),
                        Name = caption,
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_CreatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_ReadObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_UpdatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.DeleteAsync)
                {
                    m_DeletedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodAsync)
                {
                    m_MethodObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
                {
                    m_MethodContentObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }

                m_passed++;
                Console.WriteLine(string.Format("{0} OK", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", caption),
                    Name = caption,
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #region TCPWCFServiceClient
        private WCFServiceClient<SharedLibrary.Model.Adapter.Product> m_TCPWCFServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private WCFServiceClient<SharedLibrary.Model.Adapter.Product> TCPWCFServiceClient
        {
            get
            {
                if (m_TCPWCFServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_TCPWCFServiceClient = new WCFServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetTcpWCFChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("net.tcp", "127.0.0.1", "8087", "secure/product/wcf"), m_secured));
                    }
                    else
                    {
                        m_TCPWCFServiceClient = new WCFServiceClient<SharedLibrary.Model.Adapter.Product>(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetTcpWCFChannelFactory(ChannelsAndBindings<SharedLibrary.Model.Adapter.Product>.GetServiceAddress("net.tcp", "127.0.0.1", "8086", "product/wcf")));
                    }
                    
                    m_TCPWCFServiceClient.OnMessage += M_TCPWCFServiceClient_OnMessage;
                    m_TCPWCFServiceClient.OnContentObject += M_TCPWCFServiceClient_OnContentObject;
                    m_TCPWCFServiceClient.OnContentObjectList += M_TCPWCFServiceClient_OnContentObjectList;
                }
                return m_TCPWCFServiceClient;
            }
        }

        private void M_TCPWCFServiceClient_OnMessage(object message)
        {

        }

        private void M_TCPWCFServiceClient_OnContentObjectList(List<SharedLibrary.Model.Adapter.Product> contentObjectList, MethodEventArgs eventArgs)
        {
            string caption = null;

            if (eventArgs.MethodType == MethodType.ListAsync)
            {
                caption = "ListAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodContentListAsync)
            {
                caption = "MethodContentListAsync";
                m_WcfMethodContentList = contentObjectList;
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchListAsync)
            {
                caption = "MethodSearchListAsync";
                m_WcfMethodSearchList = contentObjectList;
            }

            if (eventArgs.Exception)
            {
                m_failed++;
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine(eventArgs.ExceptionMessage);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", caption),
                    Name = caption,
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }
            else
            {
                m_passed++;
                Console.WriteLine(string.Format("{0} OK.", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", caption),
                    Name = caption,
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
        }

        private void M_TCPWCFServiceClient_OnContentObject(object contentObject, MethodEventArgs eventArgs)
        {
            string caption = "";

            if (eventArgs.MethodType == MethodType.CreateAsync)
            {
                caption = "CreateAsync";
            }
            else if (eventArgs.MethodType == MethodType.ReadAsync)
            {
                caption = "ReadAsync";
            }
            else if (eventArgs.MethodType == MethodType.UpdateAsync)
            {
                caption = "UpdateAsync";
            }
            else if (eventArgs.MethodType == MethodType.DeleteAsync)
            {
                caption = "DeleteAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodAsync)
            {
                caption = "MethodAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
            {
                caption = "MethodObjectAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodContentAsync)
            {
                caption = "MethodContentAsync";
            }
            else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
            {
                caption = "MethodSearchAsync";
            }


            if (eventArgs.Exception)
            {
                Console.WriteLine("");
                Console.WriteLine(string.Format("{0} test failed.", caption));
                Console.WriteLine(string.Format("{0} returned object is null.", caption));
                Console.WriteLine("");
                Console.WriteLine(eventArgs.ExceptionMessage);

                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_failed += 4;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "CreateAsync"),
                        Name = "CreateAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_failed += 3;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "ReadAsync"),
                        Name = "ReadAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_failed += 2;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "UpdateAsync"),
                        Name = "UpdateAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "DeleteAsync"),
                        Name = "DeleteAsync",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_failed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", caption),
                        Name = caption,
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                if (eventArgs.MethodType == MethodType.CreateAsync)
                {
                    m_CreatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.ReadAsync)
                {
                    m_ReadObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.UpdateAsync)
                {
                    m_UpdatedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.DeleteAsync)
                {
                    m_DeletedObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodAsync)
                {
                    m_MethodObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodObjectAsync)
                {
                    m_MethodContentObject = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodContentAsync)
                {
                    m_WcfMethodContent = (SharedLibrary.Model.Adapter.Product)contentObject;
                }
                else if (eventArgs.MethodType == MethodType.MethodSearchAsync)
                {
                    m_WcfMethodSearchContent = (SharedLibrary.Model.Adapter.Product)contentObject;
                }

                m_passed++;
                Console.WriteLine(string.Format("{0} OK", caption));

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", caption),
                    Name = caption,
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = true
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #region HttpTests

        #region ServiceClient
        public void ExecuteHttpServiceClientTests()
        {
            System.Console.WriteLine("HTTPServiceClient tests.");
            System.Console.WriteLine("IService (ICRUD,ICRUDL) tests.");

            m_HttpServiceClient = null;
            var httpClient1 = HttpServiceClient;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;

            try
            {
                m_CreatedObject = HttpServiceClient.Create(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CREATE test failed."));
                    Console.WriteLine(string.Format("CREATE returned object is null."));

                    m_TestReports.Add(new TestReport {
                        Id = string.Format("{0}_{1}", "http", "Create"),
                        Name = "Create",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Create"),
                        Name = "Create",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "Create"),
                    Name = "Create",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    m_ReadObject = HttpServiceClient.Read(m_CreatedObject.UID.ToString());
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("READ test failed."));
                        Console.WriteLine(string.Format("READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Read"),
                            Name = "Read",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Read"),
                            Name = "Read",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Read"),
                        Name = "Read",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    m_UpdatedObject = HttpServiceClient.Update(m_ReadObject);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("UPDATE test failed."));
                        Console.WriteLine(string.Format("UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Update"),
                            Name = "Update",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Update"),
                            Name = "Update",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Update"),
                        Name = "Update",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_DeletedObject = HttpServiceClient.Delete(m_UpdatedObject);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("DELETE test failed."));
                        Console.WriteLine(string.Format("DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Delete"),
                            Name = "Delete",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "Delete"),
                            Name = "Delete",
                            Group = "http",
                            Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Delete"),
                        Name = "Delete",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "Read"),
                    Name = "Read",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "Update"),
                    Name = "Update",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "Delete"),
                    Name = "Delete",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_ListObjects = HttpServiceClient.List(new SearchInput { keyword = "" });
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("LIST test failed."));
                    Console.WriteLine(string.Format("LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "List"),
                        Name = "List",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "List"),
                        Name = "List",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "List"),
                    Name = "List",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_MethodObject = (SharedLibrary.Model.Adapter.Product)HttpServiceClient.Method("CRUD_Method");
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD Method test failed."));
                    Console.WriteLine(string.Format("CRUD Method returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Method"),
                        Name = "Method",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "Method"),
                        Name = "Method",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD Method test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "Method"),
                    Name = "Method",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var updatedMethodObject = HttpServiceClient.MethodObject(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                    Console.WriteLine(string.Format("CRUD MethodObject returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "MethodObject"),
                        Name = "MethodObject",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "MethodObject"),
                        Name = "MethodObject",
                        Group = "http",
                        Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "MethodObject"),
                    Name = "MethodObject",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }

        public void ExecuteHttpServiceClientAsyncEventTests()
        {
            System.Console.WriteLine("HTTPServiceClient Async tests.");
            System.Console.WriteLine("IService (ICRUD,ICRUDL) tests.");

            m_HttpServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;

            try
            {
                HttpServiceClient.CreateAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "CreateAsync"),
                    Name = "CreateAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            DateTime initialTime = DateTime.Now;
            //wait while object is available.
            while (m_CreatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpServiceClient.ReadAsync(m_CreatedObject.UID.ToString());
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("READAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "ReadAsync"),
                    Name = "ReadAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available.
            while (m_ReadObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                HttpServiceClient.UpdateAsync(m_ReadObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("UPDATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "UpdateAsync"),
                    Name = "UpdateAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_UpdatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpServiceClient.DeleteAsync(m_UpdatedObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("DELETEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "DeleteAsync"),
                    Name = "DeleteAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_DeletedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpServiceClient.ListAsync(new SearchInput { keyword = "" });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LISTAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "ListAsync"),
                    Name = "ListAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_ListObjects == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                HttpServiceClient.MethodAsync("CRUD_Method");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "MethodAsync"),
                    Name = "MethodAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpServiceClient.MethodObjectAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObjectAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "MethodObjectAsync"),
                    Name = "MethodObjectAsync",
                    Group = "http",
                    Url = HttpServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodContentObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }
        }
        #endregion

        #region WCFServiceClient
        public void ExecuteHttpWCFServiceClientTests()
        {
            System.Console.WriteLine("HttpWCFServiceClient tests.");
            System.Console.WriteLine("IWCFService (IService (ICRUD,ICRUDL)) Tests.");

            m_HttpWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                m_CreatedObject = HttpWCFServiceClient.Create(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CREATE test failed."));
                    Console.WriteLine(string.Format("CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Create"),
                        Name = "Create",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Create"),
                        Name = "Create",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "Create"),
                    Name = "Create",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    m_ReadObject = HttpWCFServiceClient.Read(m_CreatedObject.UID.ToString());
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("READ test failed."));
                        Console.WriteLine(string.Format("READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Read"),
                            Name = "Read",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Read"),
                            Name = "Read",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Read"),
                        Name = "Read",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    m_UpdatedObject = HttpWCFServiceClient.Update(m_ReadObject);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("UPDATE test failed."));
                        Console.WriteLine(string.Format("UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Update"),
                            Name = "Update",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Update"),
                            Name = "Update",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Update"),
                        Name = "Update",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_DeletedObject = HttpWCFServiceClient.Delete(m_UpdatedObject);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("DELETE test failed."));
                        Console.WriteLine(string.Format("DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Delete"),
                            Name = "Delete",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "Delete"),
                            Name = "Delete",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Delete"),
                        Name = "Delete",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "Read"),
                    Name = "Read",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "Update"),
                    Name = "Update",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "Delete"),
                    Name = "Delete",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_ListObjects = HttpWCFServiceClient.List(new SearchInput { keyword = "" });
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("LIST test failed."));
                    Console.WriteLine(string.Format("LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "List"),
                        Name = "List",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "List"),
                        Name = "List",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "List"),
                    Name = "List",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_MethodObject = (SharedLibrary.Model.Adapter.Product)HttpWCFServiceClient.Method("CRUD_Method");
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD Method test failed."));
                    Console.WriteLine(string.Format("CRUD Method returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Method"),
                        Name = "Method",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "Method"),
                        Name = "Method",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD Method test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "Method"),
                    Name = "Method",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var updatedMethodObject = HttpWCFServiceClient.MethodObject(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                    Console.WriteLine(string.Format("CRUD MethodObject returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodObject"),
                        Name = "MethodObject",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodObject"),
                        Name = "MethodObject",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodObject"),
                    Name = "MethodObject",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFService Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_WcfMethodContent = HttpWCFServiceClient.MethodContent(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_WCFMethodContent");
                if (m_WcfMethodContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodContent test failed."));
                    Console.WriteLine(string.Format("CRUD MethodContent returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodContent"),
                        Name = "MethodContent",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodContent"),
                        Name = "MethodContent",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContent test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodContent"),
                    Name = "MethodContent",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var contentsList = new List<SharedLibrary.Model.Adapter.Product>();
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 1", Description = "" });
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 2", Description = "" });
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 3", Description = "" });

                m_WcfMethodContentList = HttpWCFServiceClient.MethodContentList(contentsList, "CRUD_WCFMethodList");
                if (m_WcfMethodContentList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodContentList test failed."));
                    Console.WriteLine(string.Format("CRUD MethodContentList returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodContentList"),
                        Name = "MethodContentList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodContentList"),
                        Name = "MethodContentList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentList test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodContentList"),
                    Name = "MethodContentList",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_WcfMethodSearchContent = HttpWCFServiceClient.MethodSearch(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch");
                if (m_WcfMethodSearchContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodSearch test failed."));
                    Console.WriteLine(string.Format("CRUD MethodSearch returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodSearch"),
                        Name = "MethodSearch",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodSearch"),
                        Name = "MethodSearch",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearch test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodSearch"),
                    Name = "MethodSearch",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_WcfMethodSearchList = HttpWCFServiceClient.MethodSearchList(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList");
                if (m_WcfMethodSearchList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodSearchList test failed."));
                    Console.WriteLine(string.Format("CRUD MethodSearchList returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodSearchList"),
                        Name = "MethodSearchList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "MethodSearchList"),
                        Name = "MethodSearchList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchList test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodSearchList"),
                    Name = "MethodSearchList",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }

        public void ExecuteHttpWCFServiceClientAsyncEventTests()
        {
            System.Console.WriteLine("HTTPWCFServiceClient Async tests.");
            System.Console.WriteLine("IWCFService (IService(ICRUD,ICRUDL)) Tests.");

            m_HttpWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                HttpWCFServiceClient.CreateAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "CreateAsync"),
                    Name = "CreateAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            DateTime initialTime = DateTime.Now;
            //wait while object is available.
            while (m_CreatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.ReadAsync(m_CreatedObject.UID.ToString());
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("READAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "ReadAsync"),
                    Name = "ReadAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available.
            while (m_ReadObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                HttpWCFServiceClient.UpdateAsync(m_ReadObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("UPDATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "UpdateAsync"),
                    Name = "UpdateAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_UpdatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.DeleteAsync(m_UpdatedObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("DELETEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "DeleteAsync"),
                    Name = "DeleteAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_DeletedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.ListAsync(new SearchInput { keyword = "" });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LISTAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "ListAsync"),
                    Name = "ListAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_ListObjects == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                HttpWCFServiceClient.MethodAsync("CRUD_Method");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodAsync"),
                    Name = "MethodAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.MethodObjectAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObjectAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodObjectAsync"),
                    Name = "MethodObjectAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodContentObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFService Async Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                HttpWCFServiceClient.MethodContentAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_WCFMethodContent");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodContentAsync"),
                    Name = "MethodContentAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodContent == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            List<SharedLibrary.Model.Adapter.Product> contentsList = new List<SharedLibrary.Model.Adapter.Product>();
            contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 1", Description = "" });
            contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 2", Description = "" });

            try
            {
                HttpWCFServiceClient.MethodContentListAsync(contentsList, "CRUD_WCFMethodList");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentListAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodContentListAsync"),
                    Name = "MethodContentListAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodContentList == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.MethodSearchAsync(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodSearchAsync"),
                    Name = "MethodSearchAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodSearchContent == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                HttpWCFServiceClient.MethodSearchListAsync(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchListAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "MethodSearchListAsync"),
                    Name = "MethodSearchListAsync",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodSearchList == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= (m_timeout + 5)))
            { }
        }
        #endregion

        #endregion

        #region TCPTests

        #region ServiceClient
        public void ExecuteTCPServiceClientTests()
        {
            System.Console.WriteLine("TCPServiceClient tests.");
            System.Console.WriteLine("IService (ICRUD,ICRUDL) Tests.");

            m_TCPServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;

            try
            {
                m_CreatedObject = TCPServiceClient.Create(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CREATE test failed."));
                    Console.WriteLine(string.Format("CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Create"),
                        Name = "Create",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Create"),
                        Name = "Create",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "Create"),
                    Name = "Create",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    m_ReadObject = TCPServiceClient.Read(m_CreatedObject.UID.ToString());
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("READ test failed."));
                        Console.WriteLine(string.Format("READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Read"),
                            Name = "Read",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Read"),
                            Name = "Read",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Read"),
                        Name = "Read",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    m_UpdatedObject = TCPServiceClient.Update(m_ReadObject);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("UPDATE test failed."));
                        Console.WriteLine(string.Format("UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Update"),
                            Name = "Update",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Update"),
                            Name = "Update",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Update"),
                        Name = "Update",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_DeletedObject = TCPServiceClient.Delete(m_UpdatedObject);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("DELETE test failed."));
                        Console.WriteLine(string.Format("DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Delete"),
                            Name = "Delete",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "Delete"),
                            Name = "Delete",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Delete"),
                        Name = "Delete",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "Read"),
                    Name = "Read",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "Update"),
                    Name = "Update",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "Delete"),
                    Name = "Delete",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_ListObjects = TCPServiceClient.List(new SearchInput { keyword = "" });
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("LIST test failed."));
                    Console.WriteLine(string.Format("LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "List"),
                        Name = "List",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "List"),
                        Name = "List",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "List"),
                    Name = "List",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_MethodObject = (SharedLibrary.Model.Adapter.Product)TCPServiceClient.Method("CRUD_Method");
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD Method test failed."));
                    Console.WriteLine(string.Format("CRUD Method returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Method"),
                        Name = "Method",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "Method"),
                        Name = "Method",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD Method test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "Method"),
                    Name = "Method",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var updatedMethodObject = TCPServiceClient.MethodObject(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                    Console.WriteLine(string.Format("CRUD MethodObject returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "MethodObject"),
                        Name = "MethodObject",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "MethodObject"),
                        Name = "MethodObject",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "MethodObject"),
                    Name = "MethodObject",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }

        public void ExecuteTCPServiceClientAsyncEventTests()
        {
            System.Console.WriteLine("TCPServiceClient Async tests.");
            System.Console.WriteLine("IService (ICRUD,ICRUDL) Tests.");

            m_TCPServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;

            try
            {
                TCPServiceClient.CreateAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "CreateAsync"),
                    Name = "CreateAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            DateTime initialTime = DateTime.Now;
            //wait while object is available.
            while (m_CreatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPServiceClient.ReadAsync(m_CreatedObject.UID.ToString());
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("READAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "READAsync"),
                    Name = "READAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available.
            while (m_ReadObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                TCPServiceClient.UpdateAsync(m_ReadObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("UPDATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "UPDATEAsync"),
                    Name = "UPDATEAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_UpdatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPServiceClient.DeleteAsync(m_UpdatedObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("DELETEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "DeleteAsync"),
                    Name = "DeleteAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_DeletedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPServiceClient.ListAsync(new SearchInput { keyword = "" });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LISTAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "ListAsync"),
                    Name = "ListAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_ListObjects == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                TCPServiceClient.MethodAsync("CRUD_Method");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "MethodAsync"),
                    Name = "MethodAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPServiceClient.MethodObjectAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObjectAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "MethodObjectAsync"),
                    Name = "MethodObjectAsync",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodContentObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }
        }
        #endregion

        #region WCFServiceClient
        public void ExecuteWCFTCPServiceClientTests()
        {
            System.Console.WriteLine("TCPWCFServiceClient tests.");
            System.Console.WriteLine("IWCFService (IService(ICRUD,ICRUDL)) Tests.");

            m_TCPWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                m_CreatedObject = TCPWCFServiceClient.Create(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CREATE test failed."));
                    Console.WriteLine(string.Format("CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Create"),
                        Name = "Create",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Create"),
                        Name = "Create",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "Create"),
                    Name = "Create",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    m_ReadObject = TCPWCFServiceClient.Read(m_CreatedObject.UID.ToString());
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("READ test failed."));
                        Console.WriteLine(string.Format("READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Read"),
                            Name = "Read",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Read"),
                            Name = "Read",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Read"),
                        Name = "Read",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    m_UpdatedObject = TCPWCFServiceClient.Update(m_ReadObject);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("UPDATE test failed."));
                        Console.WriteLine(string.Format("UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Update"),
                            Name = "Update",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Update"),
                            Name = "Update",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Update"),
                        Name = "Update",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_DeletedObject = TCPWCFServiceClient.Delete(m_UpdatedObject);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("DELETE test failed."));
                        Console.WriteLine(string.Format("DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Delete"),
                            Name = "Delete",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "Delete"),
                            Name = "Delete",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                            Interface = "IWCFService",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Delete"),
                        Name = "Delete",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "Read"),
                    Name = "Read",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "Update"),
                    Name = "Update",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "Delete"),
                    Name = "Delete",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }


            try
            {
                m_ListObjects = TCPWCFServiceClient.List(new SearchInput { keyword = "" });
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("LIST test failed."));
                    Console.WriteLine(string.Format("LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "List"),
                        Name = "List",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "List"),
                        Name = "List",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "List"),
                    Name = "List",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_MethodObject = (SharedLibrary.Model.Adapter.Product)TCPWCFServiceClient.Method("CRUD_Method");
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD Method test failed."));
                    Console.WriteLine(string.Format("CRUD Method returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Method"),
                        Name = "Method",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "Method"),
                        Name = "Method",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD Method test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "Method"),
                    Name = "Method",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var updatedMethodObject = TCPWCFServiceClient.MethodObject(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                    Console.WriteLine(string.Format("CRUD MethodObject returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodObject"),
                        Name = "MethodObject",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodObject"),
                        Name = "MethodObject",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObject test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodObject"),
                    Name = "MethodObject",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFService Async Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                m_WcfMethodContent = TCPWCFServiceClient.MethodContent(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_WCFMethodContent");
                if (m_WcfMethodContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodContent test failed."));
                    Console.WriteLine(string.Format("CRUD MethodContent returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodContent"),
                        Name = "MethodContent",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodContent"),
                        Name = "MethodContent",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContent test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodContent"),
                    Name = "MethodContent",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var contentsList = new List<SharedLibrary.Model.Adapter.Product>();
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 1", Description = "" });
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 2", Description = "" });
                contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 3", Description = "" });

                m_WcfMethodContentList = TCPWCFServiceClient.MethodContentList(contentsList, "CRUD_WCFMethodList");
                if (m_WcfMethodContentList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodContentList test failed."));
                    Console.WriteLine(string.Format("CRUD MethodContentList returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodContentList"),
                        Name = "MethodContentList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodContentList"),
                        Name = "MethodContentList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentList test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodContentList"),
                    Name = "MethodContentList",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_WcfMethodSearchContent = TCPWCFServiceClient.MethodSearch(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch");
                if (m_WcfMethodSearchContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodSearch test failed."));
                    Console.WriteLine(string.Format("CRUD MethodSearch returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearch"),
                        Name = "MethodSearch",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearch"),
                        Name = "MethodSearch",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearch test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearch"),
                    Name = "MethodSearch",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                m_WcfMethodSearchList = TCPWCFServiceClient.MethodSearchList(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList");
                if (m_WcfMethodSearchList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("CRUD MethodSearchList test failed."));
                    Console.WriteLine(string.Format("CRUD MethodSearchList returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearchList"),
                        Name = "MethodSearchList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearchList"),
                        Name = "MethodSearchList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                        Interface = "IWCFService",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchList test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearchList"),
                    Name = "MethodSearchList",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }

        public void ExecuteWCFTCPServiceClientAsyncEventTests()
        {
            System.Console.WriteLine("TCPWCFServiceClient Async tests.");
            System.Console.WriteLine("IWCFService (IService(ICRUD,ICRUDL)) Tests.");

            m_TCPWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_MethodContentObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                TCPWCFServiceClient.CreateAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CREATEAsync test failed."));
                Console.WriteLine(ex.Message);
                
                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "CreateAsync"),
                    Name = "CreateAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            DateTime initialTime = DateTime.Now;
            //wait while object is available.
            while (m_CreatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.ReadAsync(m_CreatedObject.UID.ToString());
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("READAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "ReadAsync"),
                    Name = "ReadAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available.
            while (m_ReadObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                TCPWCFServiceClient.UpdateAsync(m_ReadObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("UPDATEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "UpdateAsync"),
                    Name = "UpdateAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_UpdatedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.DeleteAsync(m_UpdatedObject);
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("DELETEAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "DeleteAsync"),
                    Name = "DeleteAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_DeletedObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.ListAsync(new SearchInput { keyword = "" });
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("LISTAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "ListAsync"),
                    Name = "ListAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_ListObjects == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IService (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                TCPWCFServiceClient.MethodAsync("CRUD_Method");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodAsync"),
                    Name = "MethodAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.MethodObjectAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_MethodObject");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodObjectAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodObjectAsync"),
                    Name = "MethodObjectAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }


            initialTime = DateTime.Now;
            //wait while object is available
            while (m_MethodContentObject == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFService Async Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                TCPWCFServiceClient.MethodContentAsync(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "New object name", Description = "Product description." }, "CRUD_WCFMethodContent");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodContentAsync"),
                    Name = "MethodContentAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodContent == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            List<SharedLibrary.Model.Adapter.Product> contentsList = new List<SharedLibrary.Model.Adapter.Product>();
            contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 1", Description = "" });
            contentsList.Add(new SharedLibrary.Model.Adapter.Product { UID = Guid.NewGuid(), Name = "Product 2", Description = "" });

            try
            {
                TCPWCFServiceClient.MethodContentListAsync(contentsList, "CRUD_WCFMethodList");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodContentListAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodContentListAsync"),
                    Name = "MethodContentListAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodContentList == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.MethodSearchAsync(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearchAsync"),
                    Name = "MethodSearchAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodSearchContent == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= m_timeout))
            { }

            try
            {
                TCPWCFServiceClient.MethodSearchListAsync(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList");
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("CRUD MethodSearchListAsync test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "MethodSearchListAsync"),
                    Name = "MethodSearchListAsync",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryService.Endpoint.Address.ToString(),
                    Interface = "IWCFService",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            initialTime = DateTime.Now;
            //wait while object is available
            while (m_WcfMethodSearchList == null && (DateTime.Now.Subtract(initialTime).TotalSeconds <= (m_timeout + 5)))
            { }
        }
        #endregion

        #endregion

        #region PrintReport
        public void PrintReport()
        {
            int totalPassed = 0;
            int totalFailed = 0;
            int counter = 0;

            System.Console.WriteLine("Adapter Model Class WCF CRUDS Test Results Report");
            System.Console.WriteLine("=================================================");

            foreach (var report in m_TestReports)
            {
                System.Console.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t", counter, report.Group, report.Name,
                    report.Platform, report.Passed ? "OK" : "FAILED", report.Secured ? "(S)" : "", report.Interface, report.Url, ""));

                if (report.Passed)
                {
                    totalPassed++;
                }
                else
                {
                    totalFailed++;
                }

                counter++;
            }

            System.Console.WriteLine("===================");
            System.Console.WriteLine(string.Format("Passed: {0}", totalPassed));
            System.Console.WriteLine(string.Format("Failed: {0}", totalFailed));
        }
        #endregion

        #region RunTests
        public void RunTests()
        {
            #region HTTP
            /**/
            try
            {
                //7
                ExecuteHttpServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //7
                ExecuteHttpServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteHttpWCFServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteHttpWCFServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            /**/
            #endregion
            /**/
            System.Console.WriteLine("");
            System.Console.WriteLine("Running TCP Client.Standard Tests");
            System.Console.WriteLine("");

            #region TCP
            try
            {
                //7
                ExecuteTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //7
                ExecuteTCPServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/

            System.Console.WriteLine("");
            System.Console.WriteLine("Running secure tests.");
            System.Console.WriteLine("");
            Secured = true;

            var currentTime = DateTime.Now;
            //wait while object is available
            while (DateTime.Now.Subtract(currentTime).TotalSeconds <= m_timeout)
            { }

            #region HTTP
            /**/
            try
            {
                //7
                ExecuteHttpServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            /**/
            try
            {
                //7
                ExecuteHttpServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            /**/

            try
            {
                //11
                ExecuteHttpWCFServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            /**/
            try
            {
                //11
                ExecuteHttpWCFServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            /**/
            #endregion
            /**/
            System.Console.WriteLine("");
            System.Console.WriteLine("Running TCP Client.Standard Tests");
            System.Console.WriteLine("");

            #region TCP
            try
            {
                //7
                ExecuteTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //7
                ExecuteTCPServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientAsyncEventTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/
        }
        #endregion
    }
}
