﻿using ConsoleAppNETCoreFramework;
using SharedLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using WindnTrees.ICRUDS.Standard;

namespace ConsoleAppNETCoreFramework.CRUDS
{
    public class ClientAsync
    {
        int m_passed = 0;
        int m_failed = 0;
        bool m_secured = false;

        public bool Secured
        {
            get
            {
                return m_secured;
            }

            set
            {
                m_HttpServiceClient = null;
                m_HttpWCFServiceClient = null;
                m_TCPServiceClient = null;
                m_TCPWCFServiceClient = null;
                m_secured = value;
            }
        }

        Color m_CreatedObject = null;
        Color m_ReadObject = null;
        Color m_UpdatedObject = null;
        Color m_DeletedObject = null;
        List<Color> m_ListObjects = null;
        Color m_MethodObject = null;
        Color m_WcfMethodContent = null;
        List<object> m_WcfMethodContentList = null;
        Color m_WcfMethodSearchContent = null;
        List<object> m_WcfMethodSearchList = null;

        public List<TestReport> m_TestReports = new List<TestReport>();

        #region HttpServiceClient
        private ServiceClient<Color> m_HttpServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private ServiceClient<Color> HttpServiceClient
        {
            get
            {
                if (m_HttpServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_HttpServiceClient = new ServiceClient<Color>(ChannelsAndBindings<Color>.GetBasicHttpChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("https", "127.0.0.1", "8081", "secure/lists/color"), m_secured));
                    }
                    else
                    {
                        m_HttpServiceClient = new ServiceClient<Color>(ChannelsAndBindings<Color>.GetBasicHttpChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("http", "127.0.0.1", "8080", "lists/color")));
                    }
                }
                return m_HttpServiceClient;
            }
        }
        #endregion

        #region HttpWCFServiceClient
        private WCFServiceClient<Color> m_HttpWCFServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private WCFServiceClient<Color> HttpWCFServiceClient
        {
            get
            {
                if (m_HttpWCFServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_HttpWCFServiceClient = new WCFServiceClient<Color>(ChannelsAndBindings<Color>.GetBasicHttpWCFChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("https", "127.0.0.1", "8081", "secure/lists/color/wcf"), m_secured));
                    }
                    else
                    {
                        m_HttpWCFServiceClient = new WCFServiceClient<Color>(ChannelsAndBindings<Color>.GetBasicHttpWCFChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("http", "127.0.0.1", "8080", "lists/color/wcf")));
                    }
                }
                return m_HttpWCFServiceClient;
            }
        }
        #endregion

        #region TCPServiceClient
        private ServiceClient<Color> m_TCPServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private ServiceClient<Color> TCPServiceClient
        {
            get
            {
                if (m_TCPServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_TCPServiceClient = new ServiceClient<Color>(ChannelsAndBindings<Color>.GetTcpChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("net.tcp", "127.0.0.1", "8083", "secure/lists/color"), m_secured));
                    }
                    else
                    {
                        m_TCPServiceClient = new ServiceClient<Color>(ChannelsAndBindings<Color>.GetTcpChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("net.tcp", "127.0.0.1", "8082", "lists/color")));
                    }
                }
                return m_TCPServiceClient;
            }
        }
        #endregion

        #region TCPWCFServiceClient
        private WCFServiceClient<Color> m_TCPWCFServiceClient = null;
        /// <summary>
        /// Http Service Client.
        /// </summary>
        private WCFServiceClient<Color> TCPWCFServiceClient
        {
            get
            {
                if (m_TCPWCFServiceClient == null)
                {
                    if (m_secured)
                    {
                        m_TCPWCFServiceClient = new WCFServiceClient<Color>(ChannelsAndBindings<Color>.GetTcpWCFChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("net.tcp", "127.0.0.1", "8083", "secure/lists/color/wcf"), m_secured));
                    }
                    else
                    {
                        m_TCPWCFServiceClient = new WCFServiceClient<Color>(ChannelsAndBindings<Color>.GetTcpWCFChannelAsyncFactory(ChannelsAndBindings<Color>.GetServiceAddress("net.tcp", "127.0.0.1", "8082", "lists/color/wcf")));
                    }
                }
                return m_TCPWCFServiceClient;
            }
        }
        #endregion

        #region HttpTests

        #region ServiceClient
        public void ExecuteHttpServiceClientTests()
        {
            System.Console.WriteLine("HTTPServiceClient tests.");
            System.Console.WriteLine("IServiceSync (ICRUD,ICRUDL) tests.");

            m_HttpServiceClient = null;
            var httpClient1 = HttpServiceClient;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;

            try
            {
                var asyncResultCreate = HttpServiceClient.BeginCreate(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, null, null);
                while (!asyncResultCreate.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_CreatedObject = HttpServiceClient.EndCreate(asyncResultCreate);
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                    Console.WriteLine(string.Format("BEGIN_CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;
                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginCreate"),
                    Name = "BeginCreate",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    var asyncResultRead = HttpServiceClient.BeginRead(m_CreatedObject.UID.ToString(), null, null);
                    while (!asyncResultRead.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_ReadObject = HttpServiceClient.EndRead(asyncResultRead);
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_READ test failed."));
                        Console.WriteLine(string.Format("BEGIN_READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginRead"),
                            Name = "BeginRead",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginRead"),
                            Name = "BeginRead",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginRead"),
                        Name = "BeginRead",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    var asyncResultUpdate = HttpServiceClient.BeginUpdate(m_ReadObject, null, null);
                    while (!asyncResultUpdate.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_UpdatedObject = HttpServiceClient.EndUpdate(asyncResultUpdate);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                        Console.WriteLine(string.Format("BEGIN_UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginUpdate"),
                        Name = "BeginUpdate",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    var asyncResultDelete = HttpServiceClient.BeginDelete(m_UpdatedObject, null, null);
                    while (!asyncResultDelete.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_DeletedObject = HttpServiceClient.EndDelete(asyncResultDelete);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                        Console.WriteLine(string.Format("BEGIN_DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "http", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "http",
                            Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginDelete"),
                        Name = "BeginDelete",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginRead"),
                    Name = "BeginRead",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginUpdate"),
                    Name = "BeginUpdate",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginDelete"),
                    Name = "BeginDelete",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultList = HttpServiceClient.BeginList(new SearchInput { keyword = "" }, null, null);
                while (!asyncResultList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_ListObjects = HttpServiceClient.EndList(asyncResultList);
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginList"),
                        Name = "BeginList",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginList"),
                        Name = "BeginList",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginList"),
                    Name = "BeginList",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IServiceAsync (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethod = HttpServiceClient.BeginMethod("CRUD_Method", null, null);
                while (!asyncResultMethod.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_MethodObject = (Color)HttpServiceClient.EndMethod(asyncResultMethod);
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginMethod"),
                    Name = "BeginMethod",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodObject = HttpServiceClient.BeginMethodObject(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_MethodObject", null, null);
                while (!asyncResultMethodObject.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                var updatedMethodObject = HttpServiceClient.EndMethodObject(asyncResultMethodObject);
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "http", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "http",
                        Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "http", "BeginMethodObject"),
                    Name = "BeginMethodObject",
                    Group = "http",
                    Url = HttpServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }

        #endregion

        #region WCFServiceClient
        public void ExecuteHttpWCFServiceClientTests()
        {
            System.Console.WriteLine("HttpWCFServiceClient tests.");
            System.Console.WriteLine("IWCFServiceAsync (IServiceAsync (ICRUD,ICRUDL)) Tests.");

            m_HttpWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                var asyncResultCreate = HttpWCFServiceClient.BeginCreate(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, null, null);
                while (!asyncResultCreate.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_CreatedObject = HttpWCFServiceClient.EndCreate(asyncResultCreate);
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                    Console.WriteLine(string.Format("BEGIN_CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginCreate"),
                    Name = "BeginCreate",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    var asyncResultRead = HttpWCFServiceClient.BeginRead(m_CreatedObject.UID.ToString(), null, null);
                    while (!asyncResultRead.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_ReadObject = HttpWCFServiceClient.EndRead(asyncResultRead);
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_READ test failed."));
                        Console.WriteLine(string.Format("BEGIN_READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginRead"),
                            Name = "BeginRead",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginRead"),
                            Name = "BeginRead",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginRead"),
                        Name = "BeginRead",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);
                    var asyncResultUpdate = HttpWCFServiceClient.BeginUpdate(m_ReadObject, null, null);
                    while (!asyncResultUpdate.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_UpdatedObject = HttpWCFServiceClient.EndUpdate(asyncResultUpdate);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                        Console.WriteLine(string.Format("BEGIN_UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginUpdate"),
                        Name = "BeginUpdate",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    var asyncResultDelete = HttpWCFServiceClient.BeginDelete(m_UpdatedObject, null, null);
                    while (!asyncResultDelete.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_DeletedObject = HttpWCFServiceClient.EndDelete(asyncResultDelete);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                        Console.WriteLine(string.Format("BEGIN_DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "httpWCF", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "httpWCF",
                            Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginDelete"),
                        Name = "BeginDelete",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginRead"),
                    Name = "BeginRead",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginUpdate"),
                    Name = "BeginUpdate",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginDelete"),
                    Name = "BeginDelete",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }


            try
            {
                var asyncResultList = HttpWCFServiceClient.BeginList(new SearchInput { keyword = "" }, null, null);
                while (!asyncResultList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_ListObjects = HttpWCFServiceClient.EndList(asyncResultList);
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginList"),
                        Name = "BeginList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginList"),
                        Name = "BeginList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginList"),
                    Name = "BeginList",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFServiceAsync (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethod = HttpWCFServiceClient.BeginMethod("CRUD_Method", null, null);
                while (!asyncResultMethod.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_MethodObject = (Color)HttpWCFServiceClient.EndMethod(asyncResultMethod);
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethod"),
                    Name = "BeginMethod",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodObject = HttpWCFServiceClient.BeginMethodObject(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_MethodObject", null, null);
                while (!asyncResultMethodObject.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                var updatedMethodObject = HttpWCFServiceClient.EndMethodObject(asyncResultMethodObject);
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodObject"),
                    Name = "BeginMethodObject",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFServiceAsync Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethodContent = HttpWCFServiceClient.BeginMethodContent(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_WCFMethodContent", null, null);
                while (!asyncResultMethodContent.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodContent = HttpWCFServiceClient.EndMethodContent(asyncResultMethodContent);
                if (m_WcfMethodContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContent"),
                        Name = "BeginMethodContent",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContent"),
                        Name = "BeginMethodContent",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContent"),
                    Name = "BeginMethodContent",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var contentsList = new List<Color>();
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 1", Description = "" });
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 2", Description = "" });
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 3", Description = "" });

                var asyncResultContentList = HttpWCFServiceClient.BeginMethodContentList(contentsList, "CRUD_WCFMethodList", null, null);
                while (!asyncResultContentList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodContentList = HttpWCFServiceClient.EndMethodContentList(asyncResultContentList).ToList<object>();
                if (m_WcfMethodContentList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContentList"),
                        Name = "BeginMethodContentList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContentList"),
                        Name = "BeginMethodContentList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodContentList"),
                    Name = "BeginMethodContentList",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodSearch = HttpWCFServiceClient.BeginMethodSearch(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch", null, null);
                while (!asyncResultMethodSearch.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodSearchContent = HttpWCFServiceClient.EndMethodSearch(asyncResultMethodSearch);
                if (m_WcfMethodSearchContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearch"),
                        Name = "BeginMethodSearch",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearch"),
                        Name = "BeginMethodSearch",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearch"),
                    Name = "BeginMethodSearch",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultSearchList = HttpWCFServiceClient.BeginMethodSearchList(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList", null, null);
                while (!asyncResultSearchList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodSearchList = HttpWCFServiceClient.EndMethodSearchList(asyncResultSearchList).ToList<object>();
                if (m_WcfMethodSearchList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearchList"),
                        Name = "BeginMethodSearchList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearchList"),
                        Name = "BeginMethodSearchList",
                        Group = "httpWCF",
                        Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "httpWCF", "BeginMethodSearchList"),
                    Name = "BeginMethodSearchList",
                    Group = "httpWCF",
                    Url = HttpWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #endregion

        #region TCPTests

        #region ServiceClient
        public void ExecuteTCPServiceClientTests()
        {
            System.Console.WriteLine("TCPServiceClient tests.");
            System.Console.WriteLine("IServiceAsync (ICRUD,ICRUDL) Tests.");

            m_TCPServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;

            try
            {
                var asyncResultCreate = TCPServiceClient.BeginCreate(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, null, null);
                while (!asyncResultCreate.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_CreatedObject = TCPServiceClient.EndCreate(asyncResultCreate);
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                    Console.WriteLine(string.Format("BEGIN_CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginCreate"),
                    Name = "BeginCreate",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    var asyncResultRead = TCPServiceClient.BeginRead(m_CreatedObject.UID.ToString(), null, null);
                    while (!asyncResultRead.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_ReadObject = TCPServiceClient.EndRead(asyncResultRead);
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_READ test failed."));
                        Console.WriteLine(string.Format("BEGIN_READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginRead"),
                            Name = "BeginRead",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginRead"),
                            Name = "BeginRead",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginRead"),
                        Name = "BeginRead",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);

                    var asyncResultUpdate = TCPServiceClient.BeginUpdate(m_ReadObject, null, null);
                    while (!asyncResultUpdate.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_UpdatedObject = TCPServiceClient.EndUpdate(asyncResultUpdate);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                        Console.WriteLine(string.Format("BEGIN_UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginUpdate"),
                        Name = "BeginUpdate",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    var asyncResultDelete = TCPServiceClient.BeginDelete(m_UpdatedObject, null, null);
                    while (!asyncResultDelete.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_DeletedObject = TCPServiceClient.EndDelete(asyncResultDelete);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                        Console.WriteLine(string.Format("BEGIN_DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcp", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "tcp",
                            Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginDelete"),
                        Name = "BeginDelete",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginRead"),
                    Name = "BeginRead",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginUpdate"),
                    Name = "BeginUpdate",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginDelete"),
                    Name = "BeginDelete",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultList = TCPServiceClient.BeginList(new SearchInput { keyword = "" }, null, null);
                while (!asyncResultList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_ListObjects = TCPServiceClient.EndList(asyncResultList);
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginList"),
                        Name = "BeginList",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginList"),
                        Name = "BeginList",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginList"),
                    Name = "BeginList",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IServiceAsync (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethod = TCPServiceClient.BeginMethod("CRUD_Method", null, null);
                while (!asyncResultMethod.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_MethodObject = (Color)TCPServiceClient.EndMethod(asyncResultMethod);
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginMethod"),
                    Name = "BeginMethod",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodObject = TCPServiceClient.BeginMethodObject(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_MethodObject", null, null);
                while (!asyncResultMethodObject.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                var updatedMethodObject = TCPServiceClient.EndMethodObject(asyncResultMethodObject);
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcp", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "tcp",
                        Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcp", "BeginMethodObject"),
                    Name = "BeginMethodObject",
                    Group = "tcp",
                    Url = TCPServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #region WCFServiceClient
        public void ExecuteWCFTCPServiceClientTests()
        {
            System.Console.WriteLine("TCPWCFServiceClient tests.");
            System.Console.WriteLine("IWCFServiceAsync (IServiceAsync(ICRUD,ICRUDL)) Tests.");

            m_TCPWCFServiceClient = null;

            m_passed = 0;
            m_failed = 0;

            m_CreatedObject = null;
            m_ReadObject = null;
            m_UpdatedObject = null;
            m_DeletedObject = null;
            m_ListObjects = null;
            m_MethodObject = null;
            m_WcfMethodContent = null;
            m_WcfMethodContentList = null;
            m_WcfMethodSearchContent = null;
            m_WcfMethodSearchList = null;

            try
            {
                var asyncResultCreate = TCPWCFServiceClient.BeginCreate(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, null, null);
                while (!asyncResultCreate.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_CreatedObject = TCPWCFServiceClient.EndCreate(asyncResultCreate);
                if (m_CreatedObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                    Console.WriteLine(string.Format("BEGIN_CREATE returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginCreate"),
                        Name = "BeginCreate",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_CREATE test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginCreate"),
                    Name = "BeginCreate",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            if (m_CreatedObject != null)
            {
                try
                {
                    var asyncResultRead = TCPWCFServiceClient.BeginRead(m_CreatedObject.UID.ToString(), null, null);
                    while (!asyncResultRead.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_ReadObject = TCPWCFServiceClient.EndRead(asyncResultRead);
                    if (m_ReadObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_READ test failed."));
                        Console.WriteLine(string.Format("BEGIN_READ returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginRead"),
                            Name = "BeginRead",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginRead"),
                            Name = "BeginRead",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_READ test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginRead"),
                        Name = "BeginRead",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    m_ReadObject.Name = string.Format("{0} with update text", m_ReadObject.Name);

                    var asyncResultUpdate = TCPWCFServiceClient.BeginUpdate(m_ReadObject, null, null);
                    while (!asyncResultUpdate.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_UpdatedObject = TCPWCFServiceClient.EndUpdate(asyncResultUpdate);
                    if (m_UpdatedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                        Console.WriteLine(string.Format("BEGIN_UPDATE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginUpdate"),
                            Name = "BeginUpdate",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_UPDATE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginUpdate"),
                        Name = "BeginUpdate",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }

                try
                {
                    var asyncResultDelete = TCPWCFServiceClient.BeginDelete(m_UpdatedObject, null, null);
                    while (!asyncResultDelete.IsCompleted)
                    {
                        System.Threading.Thread.Sleep(10);
                    }
                    m_DeletedObject = TCPWCFServiceClient.EndDelete(asyncResultDelete);
                    if (m_DeletedObject == null)
                    {
                        m_failed++;
                        Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                        Console.WriteLine(string.Format("BEGIN_DELETE returned object is null."));

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = false
                        });
                    }
                    else
                    {
                        m_passed++;

                        m_TestReports.Add(new TestReport
                        {
                            Id = string.Format("{0}_{1}", "tcpWCF", "BeginDelete"),
                            Name = "BeginDelete",
                            Group = "tcpWCF",
                            Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                            Interface = "IWCFServiceAsync",
                            Platform = ".NET",
                            Secured = m_secured,
                            Passed = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_DELETE test failed."));
                    Console.WriteLine(ex.Message);

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginDelete"),
                        Name = "BeginDelete",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
            }
            else
            {
                m_failed += 3;

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginRead"),
                    Name = "BeginRead",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginUpdate"),
                    Name = "BeginUpdate",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginDelete"),
                    Name = "BeginDelete",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }


            try
            {
                var asyncResultList = TCPWCFServiceClient.BeginList(new SearchInput { keyword = "" }, null, null);
                while (!asyncResultList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_ListObjects = TCPWCFServiceClient.EndList(asyncResultList);
                if (m_ListObjects == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginList"),
                        Name = "BeginList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginList"),
                        Name = "BeginList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginList"),
                    Name = "BeginList",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFServiceAsync (ICRUDM) tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethod = TCPWCFServiceClient.BeginMethod("CRUD_Method", null, null);
                while (!asyncResultMethod.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_MethodObject = (Color)TCPWCFServiceClient.EndMethod(asyncResultMethod);
                if (m_MethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethod"),
                        Name = "BeginMethod",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethod"),
                    Name = "BeginMethod",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodObject = TCPWCFServiceClient.BeginMethodObject(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_MethodObject", null, null);
                while (!asyncResultMethodObject.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                var updatedMethodObject = TCPWCFServiceClient.EndMethodObject(asyncResultMethodObject);
                if (updatedMethodObject == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodObject"),
                        Name = "BeginMethodObject",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_OBJECT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodObject"),
                    Name = "BeginMethodObject",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");

            System.Console.WriteLine("");
            System.Console.WriteLine("IWCFServiceAsync Async Extended Interface Tests.");
            System.Console.WriteLine("");

            m_passed = 0;
            m_failed = 0;

            try
            {
                var asyncResultMethodContent = TCPWCFServiceClient.BeginMethodContent(new Color { UID = Guid.NewGuid(), Name = "New object name", Description = "Color description." }, "CRUD_WCFMethodContent", null, null);
                while (!asyncResultMethodContent.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodContent = TCPWCFServiceClient.EndMethodContent(asyncResultMethodContent);
                if (m_WcfMethodContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContent"),
                        Name = "BeginMethodContent",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContent"),
                        Name = "BeginMethodContent",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContent"),
                    Name = "BeginMethodContent",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var contentsList = new List<Color>();
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 1", Description = "" });
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 2", Description = "" });
                contentsList.Add(new Color { UID = Guid.NewGuid(), Name = "Color 3", Description = "" });

                var asyncResultMethodContentList = TCPWCFServiceClient.BeginMethodContentList(contentsList, "CRUD_WCFMethodList", null, null);
                while (!asyncResultMethodContentList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodContentList = TCPWCFServiceClient.EndMethodContentList(asyncResultMethodContentList).ToList<object>();
                if (m_WcfMethodContentList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContentList"),
                        Name = "BeginMethodContentList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContentList"),
                        Name = "BeginMethodContentList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_CONTENT_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodContentList"),
                    Name = "BeginMethodContentList",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodSearch = TCPWCFServiceClient.BeginMethodSearch(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearch", null, null);
                while (!asyncResultMethodSearch.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodSearchContent = TCPWCFServiceClient.EndMethodSearch(asyncResultMethodSearch);
                if (m_WcfMethodSearchContent == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearch"),
                        Name = "BeginMethodSearch",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearch"),
                        Name = "BeginMethodSearch",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearch"),
                    Name = "BeginMethodSearch",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            try
            {
                var asyncResultMethodSearchList = TCPWCFServiceClient.BeginMethodSearchList(new SearchInput { keyword = "" }, "CRUD_WCFMethodSearchList", null, null);
                while (!asyncResultMethodSearchList.IsCompleted)
                {
                    System.Threading.Thread.Sleep(10);
                }
                m_WcfMethodSearchList = TCPWCFServiceClient.EndMethodSearchList(asyncResultMethodSearchList).ToList<object>();
                if (m_WcfMethodSearchList == null)
                {
                    m_failed++;
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST test failed."));
                    Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST returned object is null."));

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearchList"),
                        Name = "BeginMethodSearchList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = false
                    });
                }
                else
                {
                    m_passed++;

                    m_TestReports.Add(new TestReport
                    {
                        Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearchList"),
                        Name = "BeginMethodSearchList",
                        Group = "tcpWCF",
                        Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                        Interface = "IWCFServiceAsync",
                        Platform = ".NET",
                        Secured = m_secured,
                        Passed = true
                    });
                }
            }
            catch (Exception ex)
            {
                m_failed++;
                Console.WriteLine(string.Format("BEGIN_METHOD_SEARCH_LIST test failed."));
                Console.WriteLine(ex.Message);

                m_TestReports.Add(new TestReport
                {
                    Id = string.Format("{0}_{1}", "tcpWCF", "BeginMethodSearchList"),
                    Name = "BeginMethodSearchList",
                    Group = "tcpWCF",
                    Url = TCPWCFServiceClient.FactoryServiceAsync.Endpoint.Address.ToString(),
                    Interface = "IWCFServiceAsync",
                    Platform = ".NET",
                    Secured = m_secured,
                    Passed = false
                });
            }

            Console.WriteLine("");
            Console.WriteLine(string.Format("TEST results (Passed/Total) {0}/{1}", m_passed, (m_passed + m_failed)));
            Console.WriteLine("");
        }
        #endregion

        #endregion

        #region PrintReport
        public void PrintReport()
        {
            int totalPassed = 0;
            int totalFailed = 0;
            int counter = 0;

            System.Console.WriteLine("Simple Model Class WCF CRUDS Test Results Report");
            System.Console.WriteLine("================================================");

            foreach (var report in m_TestReports)
            {
                System.Console.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t", counter, report.Group, report.Name,
                    report.Platform, report.Passed ? "OK" : "FAILED", report.Secured ? "(S)" : "", report.Interface, report.Url, report.Id));

                if (report.Passed)
                {
                    totalPassed++;
                }
                else
                {
                    totalFailed++;
                }

                counter++;
            }

            System.Console.WriteLine("===================");
            System.Console.WriteLine(string.Format("Passed: {0}", totalPassed));
            System.Console.WriteLine(string.Format("Failed: {0}", totalFailed));
        }
        #endregion

        #region RunTests
        public void RunTests()
        {
            #region HTTP
            try
            {
                //7
                ExecuteHttpServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteHttpWCFServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/
            System.Console.WriteLine("");
            System.Console.WriteLine("Running TCP Client Tests");
            System.Console.WriteLine("");

            #region TCP
            try
            {
                //7
                ExecuteTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/

            System.Console.WriteLine("");
            System.Console.WriteLine("Running secure tests.");
            System.Console.WriteLine("");
            Secured = true;

            var currentTime = DateTime.Now;
            //wait while object is available
            while (DateTime.Now.Subtract(currentTime).TotalSeconds <= 5)
            { }

            #region HTTP
            /**/
            try
            {
                //7
                ExecuteHttpServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteHttpWCFServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/
            System.Console.WriteLine("");
            System.Console.WriteLine("Running TCP Client Tests");
            System.Console.WriteLine("");

            #region TCP
            try
            {
                //7
                ExecuteTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            try
            {
                //11
                ExecuteWCFTCPServiceClientTests();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            #endregion
            /**/
        }
        #endregion
    }
}
