﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace SharedLibrary.Model
{
    [DataContract]
    public class Product
    {
        [DataMember]
        public System.Guid UID { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public List<ProductFeature> ProductFeatures = new List<ProductFeature>();
    }
}
