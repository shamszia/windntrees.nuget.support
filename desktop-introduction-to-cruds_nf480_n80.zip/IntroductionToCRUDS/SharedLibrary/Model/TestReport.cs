﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedLibrary.Model
{
    public class TestReport
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Group { get; set; }
        public string Interface { get; set; }
        public string Url { get; set; }
        public string Platform { get; set; }
        public bool Secured { get; set; }
        public bool Passed { get; set; }
    }
}
