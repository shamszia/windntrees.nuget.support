﻿using System.Runtime.Serialization;

namespace SharedLibrary.Model
{
    [DataContract]
    public partial class Color
    {
        [DataMember]
        public System.Guid UID { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public byte[] RowVersion { get; set; }
    }
}
