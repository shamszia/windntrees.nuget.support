﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace SharedLibrary.Model.Adapter
{
    [DataContract]
    [KnownType(typeof(List<ProductFeature>))]
    public class Product
    {
        [DataMember]
        public System.Guid UID { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public object ProductFeatures = new List<ProductFeature>();
    }
}
