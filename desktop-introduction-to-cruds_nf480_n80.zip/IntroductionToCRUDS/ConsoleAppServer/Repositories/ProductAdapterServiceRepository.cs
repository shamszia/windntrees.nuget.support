﻿using SharedLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindnTrees.CRUDS;
using WindnTrees.CRUDS.Repository;
using WindnTrees.ICRUDS;

namespace ConsoleAppServer.Repositories
{
    /// <summary>
    /// Adapter service repository provide exchange between entityframework supported Dbset data type and 
    /// </summary>
    public class ProductAdapterServiceRepository : AdapterServiceRepository<SharedLibrary.Model.Adapter.Product, SharedLibrary.Model.Product>
    {
        public ProductAdapterServiceRepository()
        {
        }

        #region AdapterMethods
        protected override EntityRepository<SharedLibrary.Model.Product> GetRepository()
        {
            return new ProductServiceRepository();
        }

        protected override SharedLibrary.Model.Adapter.Product GetAdapterEntity(SharedLibrary.Model.Product contentObject)
        {
            return new SharedLibrary.Model.Adapter.Product
            {
                UID = contentObject.UID,
                Name = contentObject.Name,
                Description = contentObject.Description
            };
        }

        protected override List<SharedLibrary.Model.Adapter.Product> GetAdapterList(List<SharedLibrary.Model.Product> list)
        {
            var listAdaptedProducts = new List<SharedLibrary.Model.Adapter.Product>();

            foreach (var product in list)
            {
                listAdaptedProducts.Add(new SharedLibrary.Model.Adapter.Product
                {
                    UID = product.UID,
                    Name = product.Name,
                    Description = product.Description
                });
            }

            return listAdaptedProducts;
        }

        protected override SharedLibrary.Model.Product GetEFEntity(SharedLibrary.Model.Adapter.Product contentObject)
        {
            return new SharedLibrary.Model.Product
            {
                UID = contentObject.UID,
                Name = contentObject.Name,
                Description = contentObject.Description
            };
        }

        protected override List<SharedLibrary.Model.Product> GetEFList(List<SharedLibrary.Model.Adapter.Product> list)
        {
            var listAdaptedProducts = new List<SharedLibrary.Model.Product>();

            foreach (var product in list)
            {
                listAdaptedProducts.Add(new SharedLibrary.Model.Product
                {
                    UID = product.UID,
                    Name = product.Name,
                    Description = product.Description
                });
            }

            return listAdaptedProducts;
        } 
        #endregion

        #region ICRUDM
        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <returns></returns>
        public object CRUD_Method()
        {
            return new Product { UID = Guid.NewGuid(), Name = "Product name", Description = "Product description here" };
        }
        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <returns></returns>
        public object CRUD_MethodObject(object contentObject)
        {
            return contentObject;
        }
        #endregion

        #region CRUD_WCFMethod

        public Product CRUD_WCFMethodContent(Product contentObject)
        {
            return contentObject;
        }

        public List<Product> CRUD_WCFMethodList(List<Product> contentObject)
        {
            return contentObject;
        }

        public Product CRUD_WCFMethodSearch(SearchInput searchInput)
        {
            return new Product { UID = Guid.NewGuid(), Name = "WCFMethodSearch", Description = "" };
        }

        public List<Product> CRUD_WCFMethodSearchList(SearchInput searchInput)
        {
            List<Product> products = new List<Product>();
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Red", Description = "" });
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Green", Description = "" });
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Blue", Description = "" });

            return products;
        }

        #endregion

        //Add additional repository methods here (supporting (IService or IWCFService) extension) and call appropriate target methods with or without input contentObject from CRUD client applications.
        //There is no need to extend service interfaces (IService or IWCFService) for extended methods.
        //Note: IWCFService is the only fully supported extension interface.
    }
}
