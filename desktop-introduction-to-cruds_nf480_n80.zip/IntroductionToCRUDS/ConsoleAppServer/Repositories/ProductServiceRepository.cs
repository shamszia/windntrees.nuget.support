﻿using SharedLibrary.Model;
using System;
using System.Collections.Generic;
using WindnTrees.CRUDS.Repository;
using WindnTrees.ICRUDS;

namespace ConsoleAppServer.Repositories
{
    public class ProductServiceRepository : ServiceRepository<SharedLibrary.Model.Product>
    {
        public ProductServiceRepository()
            : base(new ApplicationDbContext())
        {
            
        }

        #region ICRUDL
        public override Product Create(Product contentObject)
        {
            return new Product
            {
                UID = Guid.NewGuid(),
                Name = "New Product",
                Description = ""
            };
        }

        public override Product Read(object id)
        {
            return new Product
            {
                UID = Guid.NewGuid(),
                Name = "Read Product",
                Description = ""
            };
        }

        public override Product Update(Product contentObject)
        {
            return new Product
            {
                UID = Guid.NewGuid(),
                Name = "Update Product",
                Description = ""
            };
        }

        public override Product Delete(Product contentObject)
        {
            return new Product
            {
                UID = Guid.NewGuid(),
                Name = "Deleted Product",
                Description = ""
            };
        }

        public override List<Product> List(SearchInput queryObject)
        {
            var listProducts = new List<Product>();
            listProducts.Add(new Product { UID = Guid.NewGuid(), Name = "Product 1", Description = "" });
            listProducts.Add(new Product { UID = Guid.NewGuid(), Name = "Product 2", Description = "" });
            listProducts.Add(new Product { UID = Guid.NewGuid(), Name = "Product 3", Description = "" });

            return listProducts;
        }
        #endregion

        #region ICRUDM
        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <returns></returns>
        public object CRUD_Method()
        {
            var colorObject = new Product { UID = Guid.NewGuid(), Name = "CRUD_Method", Description = "" };
            return colorObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public object CRUD_MethodObject(object contentObject)
        {
            ((Product)contentObject).UID = Guid.NewGuid();
            return contentObject;
        }
        #endregion

        #region CRUD_IWCFService
        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public Product CRUD_WCFMethodContent(Product contentObject)
        {
            ((Product)contentObject).UID = Guid.NewGuid();
            return contentObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public List<Product> CRUD_WCFMethodList(List<Product> contentObject)
        {
            return contentObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public Product CRUD_WCFMethodSearch(SearchInput searchInput)
        {
            return new Product { UID = Guid.NewGuid(), Name = "WCFMethodSearch", Description = "" };
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public List<Product> CRUD_WCFMethodSearchList(SearchInput searchInput)
        {
            List<Product> products = new List<Product>();
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Red", Description = "" });
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Green", Description = "" });
            products.Add(new Product { UID = Guid.NewGuid(), Name = "Blue", Description = "" });

            return products;
        }
        #endregion

        //Add additional repository methods here (supporting (IService or IWCFService) extension) and call appropriate target methods with or without input contentObject from CRUD client applications.
        //There is no need to extend service interfaces (IService or IWCFService) for extended repository methods.
        //Note: IWCFService is the only fully supported extension interface in CRUDS and ICRUDS libaries.
    }
}
