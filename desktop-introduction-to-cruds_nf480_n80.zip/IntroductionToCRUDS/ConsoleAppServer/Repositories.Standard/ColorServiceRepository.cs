﻿using SharedLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindnTrees.CRUDS.Repository.Standard;
using WindnTrees.ICRUDS.Standard;

namespace ConsoleAppServer.Repositories.Standard
{
    public class ColorServiceRepository : ServiceRepository<Color>
    {
        public ColorServiceRepository()
            : base(new ApplicationDbContext())
        {   

        }

        #region ICRUDL
        public override Color Create(Color contentObject)
        {
            return new Color
            {
                UID = Guid.NewGuid(),
                Name = "Color 1",
                Description = "Description 1"
            };
        }

        public override Color Read(object id)
        {
            return new Color
            {
                UID = Guid.NewGuid(),
                Name = "Read Color 1",
                Description = "Description 1"
            };
        }

        public override Color Update(Color contentObject)
        {
            return new Color
            {
                UID = Guid.NewGuid(),
                Name = "Updated Color 1",
                Description = "Description 1"
            };
        }

        public override Color Delete(Color contentObject)
        {
            return new Color
            {
                UID = Guid.NewGuid(),
                Name = "Deleted Color 1",
                Description = "Description 1"
            };
        }

        public override List<Color> List(SearchInput queryObject)
        {
            var listColors = new List<Color>();
            listColors.Add(new Color { UID = Guid.NewGuid(), Name = "Color 1", Description = "" });
            listColors.Add(new Color { UID = Guid.NewGuid(), Name = "Color 2", Description = "" });
            listColors.Add(new Color { UID = Guid.NewGuid(), Name = "Color 3", Description = "" });

            return listColors;
        }
        #endregion

        #region ICRUDM
        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <returns></returns>
        public object CRUD_Method()
        {
            var colorObject = new Color { UID = Guid.NewGuid(), Name = "CRUD_Method", Description = "" };
            return colorObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension allows client applications to invoke remote service repository methods without concrete interface definitions. 
        /// Current version of WCF does not support ICRUDM with object return type serialization natively, use IWCFService with client applications instead.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public object CRUD_MethodObject(object contentObject)
        {
            ((Color)contentObject).UID = Guid.NewGuid();
            return contentObject;
        }
        #endregion

        #region CRUD_IWCFService
        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public Color CRUD_WCFMethodContent(Color contentObject)
        {
            ((Color)contentObject).UID = Guid.NewGuid();
            return contentObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="contentObject"></param>
        /// <returns></returns>
        public List<Color> CRUD_WCFMethodList(List<Color> contentObject)
        {
            return contentObject;
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public Color CRUD_WCFMethodSearch(SearchInput searchInput)
        {
            return new Color { UID = Guid.NewGuid(), Name = "WCFMethodSearch", Description = "" };
        }

        /// <summary>
        /// CRUDM (CRUD Method) extension (with alternative solution to ICRUDM) allows client applications to invoke remote service repository methods without concrete interface definitions.
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public List<Color> CRUD_WCFMethodSearchList(SearchInput searchInput)
        {
            List<Color> colors = new List<Color>();
            colors.Add(new Color { UID = Guid.NewGuid(), Name = "Red", Description = "" });
            colors.Add(new Color { UID = Guid.NewGuid(), Name = "Green", Description = "" });
            colors.Add(new Color { UID = Guid.NewGuid(), Name = "Blue", Description = "" });

            return colors;
        }
        #endregion

        //Add additional repository methods here (supporting (IService or IWCFService) extension) and call appropriate target methods with or without input contentObject from CRUD client applications.
        //There is no need to extend service interfaces (IService or IWCFService) for extended methods.
        //Note: IWCFService is the only fully supported extension interface in CRUDS and ICRUDS libaries.
    }
}
