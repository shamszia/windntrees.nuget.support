﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Threading.Tasks;

namespace ConsoleAppServer
{
    /// <summary>
    /// Application server hosting pipe, tcp and http channel services.
    /// </summary>
    public class ApplicationServer : WindnTrees.CRUDS.Indigo.Server
    {
        protected override ServiceHost DefineCustomEndPoints(string bindingType, string ipAddress, string port, string relativeAddress, Type serviceInterface, Type serviceType, bool enableSecurity, int timeOutInMinutes, int maxBufferSize, int maxMessageSize, int maxRecords, int arrayLength, int nodeDepth)
        {
            var host = new ServiceHost(serviceType, new Uri(GetAddress(bindingType, ipAddress, port, enableSecurity)));

            if (enableSecurity)
            {
                SetHttpsAuthorizationPolicy(host);
                //host.Credentials.ServiceCertificate.SetCertificate(ConfigurationManager.AppSettings["ssl-certificate-subject"], System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine, System.Security.Cryptography.X509Certificates.StoreName.My);
                //host.Credentials.ClientCertificate.SetCertificate(ConfigurationManager.AppSettings["ssl-certificate-subject"], System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine, System.Security.Cryptography.X509Certificates.StoreName.My);

                if (bindingType.StartsWith("custom.basic.http"))
                {
                    BasicHttpsBinding basicHttpsBinding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
                    basicHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
                    basicHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
                    //basicHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
                    //basicHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                    //basicHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.Certificate;
                    basicHttpsBinding.MessageEncoding = WSMessageEncoding.Text;
                    basicHttpsBinding.TextEncoding = System.Text.Encoding.UTF8;
                    basicHttpsBinding.TransferMode = TransferMode.Streamed;
                    basicHttpsBinding.TransferMode = TransferMode.Streamed;
                    basicHttpsBinding.MaxReceivedMessageSize = maxMessageSize;
                    basicHttpsBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, basicHttpsBinding, relativeAddress);
                }
                else
                {
                    NetHttpsBinding netHttpsBinding = new NetHttpsBinding(BasicHttpsSecurityMode.Transport);
                    netHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
                    //netHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
                    //netHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                    //netHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.Certificate;
                    netHttpsBinding.TransferMode = TransferMode.Streamed;
                    netHttpsBinding.MaxReceivedMessageSize = maxMessageSize;
                    netHttpsBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, netHttpsBinding, relativeAddress);
                }
            }
            else
            {
                if (bindingType.StartsWith("custom.basic.http"))
                {
                    BasicHttpBinding basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.None);
                    basicHttpBinding.MessageEncoding = WSMessageEncoding.Text;
                    basicHttpBinding.TextEncoding = System.Text.Encoding.UTF8;
                    basicHttpBinding.TransferMode = TransferMode.Streamed;
                    basicHttpBinding.MaxReceivedMessageSize = maxMessageSize;
                    basicHttpBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, basicHttpBinding, relativeAddress);
                }
                else
                {
                    NetHttpBinding netHttpBinding = new NetHttpBinding(BasicHttpSecurityMode.None);
                    netHttpBinding.MessageEncoding = NetHttpMessageEncoding.Text;
                    netHttpBinding.TextEncoding = System.Text.Encoding.UTF8;
                    netHttpBinding.TransferMode = TransferMode.Streamed;
                    netHttpBinding.MaxReceivedMessageSize = maxMessageSize;
                    netHttpBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, netHttpBinding, relativeAddress);
                }
            }

            return host;
        }

        /// <summary>
        /// Setup and host services.
        /// </summary>
        public override void StartServices()
        {
            //Supported binding types are net.tcp, net.pipe and http that do not require custom configurations.
            //StartService method does not process binding types that start with "custom.[name]" like "custom.basic.http"
            //instead these are processed in DefineCustomEndPoints ovrriden function to support custom configurations.

            StartService("HTTP.Color", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8080", "/lists/color", 1, false);
            StartService("HTTP.Color.Secure", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8081", "/secure/lists/color", 1, true);
            StartService("HTTP.Color.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8080", "/lists/color/wcf", 1, false);
            StartService("HTTP.Color.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8081", "/secure/lists/color/wcf", 1, true);
            StartService("HTTP.Product", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8080", "/product", 1, false);
            StartService("HTTP.Product.Secure", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8081", "/secure/product", 1, true);
            StartService("HTTP.Product.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8080", "/product/wcf", 1, false);
            StartService("HTTP.Product.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8081", "/secure/product/wcf", 1, true);
            
            StartService("TCP.Color", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8082", "/lists/color", 1, false);
            StartService("TCP.Color.Secure", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8083", "/secure/lists/color", 1, true);
            StartService("TCP.Color.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8082", "/lists/color/wcf", 1, false);
            StartService("TCP.Color.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8083", "/secure/lists/color/wcf", 1, true);
            StartService("TCP.Product", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8082", "/product", 1, false);
            StartService("TCP.Product.Secure", typeof(WindnTrees.ICRUDS.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8083", "/secure/product", 1, true);
            StartService("TCP.Product.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8082", "/product/wcf", 1, false);
            StartService("TCP.Product.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8083", "/secure/product/wcf", 1, true);
            
            StartService("HTTP.Color.Standard", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8084", "/lists/color", 1, false);
            StartService("HTTP.Color.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8085", "/secure/lists/color", 1, true);
            StartService("HTTP.Color.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8084", "/lists/color/wcf", 1, false);
            StartService("HTTP.Color.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "custom.basic.http", "127.0.0.1", "8085", "/secure/lists/color/wcf", 1, true);
            StartService("HTTP.Product.Standard", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8084", "/product", 1, false);
            StartService("HTTP.Product.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8085", "/secure/product", 1, true);
            StartService("HTTP.Product.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8084", "/product/wcf", 1, false);
            StartService("HTTP.Product.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "custom.basic.http", "127.0.0.1", "8085", "/secure/product/wcf", 1, true);
            
            StartService("TCP.Color.Standard", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8086", "/lists/color", 1, false);
            StartService("TCP.Color.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8087", "/secure/lists/color", 1, true);
            StartService("TCP.Color.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8086", "/lists/color/wcf", 1, false);
            StartService("TCP.Color.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Color>), typeof(Repositories.Standard.ColorServiceRepository), null, "net.tcp", "127.0.0.1", "8087", "/secure/lists/color/wcf", 1, true);
            StartService("TCP.Product.Standard", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8086", "/product", 1, false);
            StartService("TCP.Product.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8087", "/secure/product", 1, true);
            StartService("TCP.Product.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8086", "/product/wcf", 1, false);
            StartService("TCP.Product.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<SharedLibrary.Model.Adapter.Product>), typeof(Repositories.Standard.ProductAdapterServiceRepository), null, "net.tcp", "127.0.0.1", "8087", "/secure/product/wcf", 1, true);
        }

        /// <summary>
        /// Stop service hosting.
        /// </summary>
        public override void StopServices()
        {
            StopService("HTTP.Color");
            StopService("HTTP.Color.Secure");
            StopService("HTTP.Color.IWCFService");
            StopService("HTTP.Color.IWCFService.Secure");
            StopService("HTTP.Product");
            StopService("HTTP.Product.Secure");
            StopService("HTTP.Product.IWCFService");
            StopService("HTTP.Product.IWCFService.Secure");
            
            StopService("TCP.Color");
            StopService("TCP.Color.Secure");
            StopService("TCP.Color.IWCFService");
            StopService("TCP.Color.IWCFService.Secure");
            StopService("TCP.Product");
            StopService("TCP.Product.Secure");
            StopService("TCP.Product.IWCFService");
            StopService("TCP.Product.IWCFService.Secure");
            
            StopService("HTTP.Color.Standard");
            StopService("HTTP.Color.Standard.Secure");
            StopService("HTTP.Color.IWCFService.Standard");
            StopService("HTTP.Color.IWCFService.Standard.Secure");
            StopService("HTTP.Product.Standard");
            StopService("HTTP.Product.Standard.Secure");
            StopService("HTTP.Product.IWCFService.Standard");
            StopService("HTTP.Product.IWCFService.Standard.Secure");
            
            StopService("TCP.Color.Standard");
            StopService("TCP.Color.Standard.Secure");
            StopService("TCP.Color.IWCFService.Standard");
            StopService("TCP.Color.IWCFService.Standard.Secure");
            StopService("TCP.Product.Standard");
            StopService("TCP.Product.Standard.Secure");
            StopService("TCP.Product.IWCFService.Standard");
            StopService("TCP.Product.IWCFService.Standard.Secure");            
        }
    }
}