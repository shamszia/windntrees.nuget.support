﻿using System;

namespace ConsoleAppNETFramework
{
    public class Program
    {
        static void Main(string[] args)
        {
            var crudsClient = new CRUDS.Client();
            var crudsAdapterClient = new CRUDS.AdapterClient();
            var crudsClientAsync = new CRUDS.ClientAsync();
            var crudsAdapterClientAsync = new CRUDS.AdapterClientAsync();

            System.Console.WriteLine("");
            System.Console.WriteLine("Running HTTP Client Tests");            
            System.Console.WriteLine("Press enter key to continue");
            System.Console.WriteLine("");
            System.Console.ReadLine();

            crudsClient.RunTests();
            crudsAdapterClient.RunTests();
            crudsClientAsync.RunTests();
            crudsAdapterClientAsync.RunTests();

            System.Console.WriteLine("");
            crudsClient.PrintReport();
            System.Console.ReadLine();
            crudsAdapterClient.PrintReport();
            System.Console.ReadLine();
            crudsClientAsync.PrintReport();
            System.Console.ReadLine();
            crudsAdapterClientAsync.PrintReport();
            System.Console.ReadLine();
            System.Console.WriteLine("");
            System.Console.WriteLine("Press enter key to exit test program.");
            System.Console.ReadLine();
        }
    }
}
