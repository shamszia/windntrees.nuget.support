﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Application.WCF.Server
{   
    public class CRUDSServer : WindnTrees.CRUDS.Indigo.Server
    {
        protected override ServiceHost DefineCustomEndPoints(string bindingType, string ipAddress, string port, string relativeAddress, Type serviceInterface, Type serviceType, bool enableSecurity, int timeOutInMinutes, int maxBufferSize, int maxMessageSize, int maxRecords, int arrayLength, int nodeDepth)
        {
            var host = new ServiceHost(serviceType, new Uri(GetAddress(bindingType, ipAddress, port, enableSecurity)));

            if (enableSecurity)
            {
                SetHttpsAuthorizationPolicy(host);
                //host.Credentials.ServiceCertificate.SetCertificate(ConfigurationManager.AppSettings["ssl-certificate-subject"], System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine, System.Security.Cryptography.X509Certificates.StoreName.My);
                //host.Credentials.ClientCertificate.SetCertificate(ConfigurationManager.AppSettings["ssl-certificate-subject"], System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine, System.Security.Cryptography.X509Certificates.StoreName.My);

                if (bindingType.StartsWith("custom.basic.http"))
                {
                    BasicHttpsBinding basicHttpsBinding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
                    basicHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
                    //basicHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
                    //basicHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                    //basicHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.Certificate;
                    basicHttpsBinding.MessageEncoding = WSMessageEncoding.Text;
                    basicHttpsBinding.TextEncoding = System.Text.Encoding.UTF8;
                    basicHttpsBinding.TransferMode = TransferMode.Streamed;
                    basicHttpsBinding.MaxReceivedMessageSize = maxMessageSize;
                    basicHttpsBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, basicHttpsBinding, relativeAddress);
                }
                else
                {
                    NetHttpsBinding netHttpsBinding = new NetHttpsBinding(BasicHttpsSecurityMode.Transport);
                    netHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
                    //netHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;
                    //netHttpsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
                    //netHttpsBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.Certificate;
                    netHttpsBinding.TransferMode = TransferMode.Streamed;
                    netHttpsBinding.MaxReceivedMessageSize = maxMessageSize;
                    netHttpsBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, netHttpsBinding, relativeAddress);
                }
            }
            else
            {
                if (bindingType.StartsWith("custom.basic.http"))
                {
                    BasicHttpBinding basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.None);
                    basicHttpBinding.MessageEncoding = WSMessageEncoding.Text;
                    basicHttpBinding.TextEncoding = System.Text.Encoding.UTF8;
                    basicHttpBinding.TransferMode = TransferMode.Streamed;
                    basicHttpBinding.MaxReceivedMessageSize = maxMessageSize;
                    basicHttpBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, basicHttpBinding, relativeAddress);
                }
                else
                {
                    NetHttpBinding netHttpBinding = new NetHttpBinding(BasicHttpSecurityMode.None);
                    netHttpBinding.MessageEncoding = NetHttpMessageEncoding.Text;
                    netHttpBinding.TextEncoding = System.Text.Encoding.UTF8;
                    netHttpBinding.TransferMode = TransferMode.Streamed;
                    netHttpBinding.MaxReceivedMessageSize = maxMessageSize;
                    netHttpBinding.ReceiveTimeout = new TimeSpan(0, timeOutInMinutes, 0);
                    host.AddServiceEndpoint(serviceInterface, netHttpBinding, relativeAddress);
                }
            }

            return host;
        }

        public override void StartServices()
        {
            //.NET
            //////////////////////////////////////////

            //HTTP Services
            StartService("HTTP.Product.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.ProductRepository), null, "http.basic", "127.0.0.1", "9090", "/product", 1, false);
            StartService("HTTP.Product.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.ProductRepository), null, "http.basic", "127.0.0.1", "9091", "/secure/product", 1, true);

            //TCP Services
            StartService("TCP.Product.IWCFService", typeof(WindnTrees.ICRUDS.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.ProductRepository), null, "net.tcp", "127.0.0.1", "9092", "/product", 1, false);
            StartService("TCP.Product.IWCFService.Secure", typeof(WindnTrees.ICRUDS.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.ProductRepository), null, "net.tcp", "127.0.0.1", "9093", "/secure/product", 1, true);

            //.NET Core
            //////////////////////////////////////////

            //HTTP Services
            StartService("HTTP.Product.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.Standard.ProductRepository), null, "http.basic", "127.0.0.1", "9094", "/product", 1, false);
            StartService("HTTP.Product.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.Standard.ProductRepository), null, "http.basic", "127.0.0.1", "9095", "/secure/product", 1, true);
            
            //TCP Services
            StartService("TCP.Product.IWCFService.Standard", typeof(WindnTrees.ICRUDS.Standard.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.Standard.ProductRepository), null, "net.tcp", "127.0.0.1", "9096", "/product", 1, false);
            StartService("TCP.Product.IWCFService.Standard.Secure", typeof(WindnTrees.ICRUDS.Standard.IWCFService<Application.Models.Standard.DataAccess.Product>), typeof(Application.WCF.Server.Repositories.Standard.ProductRepository), null, "net.tcp", "127.0.0.1", "9097", "/secure/product", 1, true);
        }

        public override void StopServices()
        {
            //.NET
            StopService("HTTP.Product.IWCFService");
            StopService("HTTP.Product.IWCFService.Secure");
            StopService("TCP.Product.IWCFService");
            StopService("TCP.Product.IWCFService.Secure");

            //.NET Core
            StopService("HTTP.Product.IWCFService.Standard");
            StopService("HTTP.Product.IWCFService.Standard.Secure");
            StopService("TCP.Product.IWCFService.Standard");
            StopService("TCP.Product.IWCFService.Standard.Secure");
        }
    }
}