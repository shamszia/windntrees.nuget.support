﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using WindnTrees.Abstraction.Core.Controllers;
using WindnTrees.CRUDS.Repository.Core;
using WindnTrees.ICRUDS.Standard;
using WindnTreesSEO.Models.Database;
using WindnTreesSEO.Models.Database.Repositories;
using Newtonsoft.Json;

namespace WindnTreesSEO.Controllers
{
    public class CategoryController : CRUDLController<Category>
    {
        protected override DbContext GetDBContext()
        {
            return new ApplicationContext();
        }

        protected override EntityRepository<Category> GetRepository()
        {
            return new CategoryRepository((ApplicationContext)GetDBContext());
        }
    }
}